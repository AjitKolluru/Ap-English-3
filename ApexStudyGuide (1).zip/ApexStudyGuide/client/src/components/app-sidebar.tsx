import { Link, useLocation } from "wouter";
import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarMenuSub,
  SidebarMenuSubButton,
  SidebarMenuSubItem,
  SidebarHeader,
  SidebarFooter
} from "@/components/ui/sidebar";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
import { ChevronDown, Home } from "lucide-react";
import { sections } from "@/data/sections";
import * as Icons from "lucide-react";

export function AppSidebar() {
  const [location] = useLocation();

  const getIcon = (iconName: string) => {
    const Icon = Icons[iconName as keyof typeof Icons] as any;
    return Icon || Icons.FileText;
  };

  return (
    <Sidebar data-testid="sidebar-main">
      <SidebarHeader className="border-b p-4">
        <Link href="/">
          <div className="flex items-center gap-2 cursor-pointer hover-elevate p-2 rounded-md" data-testid="link-sidebar-home">
            <Home className="h-5 w-5 text-primary" />
            <span className="font-bold text-lg">AP Lang Guide</span>
          </div>
        </Link>
      </SidebarHeader>
      
      <SidebarContent>
        <SidebarGroup>
          <SidebarGroupLabel>Navigation</SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {sections.map((section) => {
                const IconComponent = getIcon(section.icon);
                const hasSubsections = section.subsections && section.subsections.length > 0;
                
                if (!hasSubsections) {
                  return (
                    <SidebarMenuItem key={section.id}>
                      <SidebarMenuButton asChild>
                        <Link href={`/${section.id}`} data-testid={`link-section-${section.id}`}>
                          <IconComponent className="h-4 w-4" />
                          <span>{section.title}</span>
                        </Link>
                      </SidebarMenuButton>
                    </SidebarMenuItem>
                  );
                }

                return (
                  <Collapsible key={section.id} defaultOpen={section.subsections.some(sub => location === sub.path)}>
                    <SidebarMenuItem>
                      <CollapsibleTrigger asChild>
                        <SidebarMenuButton data-testid={`button-section-${section.id}`}>
                          <IconComponent className="h-4 w-4" />
                          <span>{section.title}</span>
                          <ChevronDown className="ml-auto h-4 w-4 transition-transform group-data-[state=open]:rotate-180" />
                        </SidebarMenuButton>
                      </CollapsibleTrigger>
                      <CollapsibleContent>
                        <SidebarMenuSub>
                          {section.subsections.map((subsection) => (
                            <SidebarMenuSubItem key={subsection.id}>
                              <SidebarMenuSubButton 
                                asChild
                                isActive={location === subsection.path}
                                data-testid={`link-subsection-${subsection.id}`}
                              >
                                <Link href={subsection.path}>
                                  <span>{subsection.title}</span>
                                </Link>
                              </SidebarMenuSubButton>
                            </SidebarMenuSubItem>
                          ))}
                        </SidebarMenuSub>
                      </CollapsibleContent>
                    </SidebarMenuItem>
                  </Collapsible>
                );
              })}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
      </SidebarContent>

      <SidebarFooter className="border-t p-4">
        <div className="text-xs text-muted-foreground">
          <p className="mb-1">Open Source AP Lang Guide</p>
          <a 
            href="https://github.com" 
            target="_blank" 
            rel="noopener noreferrer"
            className="text-primary hover:underline"
            data-testid="link-github"
          >
            View on GitHub
          </a>
        </div>
      </SidebarFooter>
    </Sidebar>
  );
}
