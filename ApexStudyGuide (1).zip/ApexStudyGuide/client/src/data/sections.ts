import { Section } from "@shared/schema";

export const sections: Section[] = [
  {
    id: "overview",
    title: "Exam Overview",
    icon: "BookOpen",
    subsections: [
      { id: "exam-format", title: "Exam Format & Structure", path: "/overview/format" },
      { id: "scoring", title: "Scoring & Grading", path: "/overview/scoring" },
      { id: "timeline", title: "Test Day Timeline", path: "/overview/timeline" }
    ]
  },
  {
    id: "rhetorical-analysis",
    title: "Rhetorical Analysis",
    icon: "Search",
    subsections: [
      { id: "ra-overview", title: "Overview & Strategy", path: "/rhetorical-analysis/overview" },
      { id: "spacecat", title: "SPACECAT Framework", path: "/rhetorical-analysis/spacecat" },
      { id: "ra-examples", title: "Annotated Examples", path: "/rhetorical-analysis/examples" },
      { id: "ra-rubric", title: "Scoring Rubric", path: "/rhetorical-analysis/rubric" }
    ]
  },
  {
    id: "argument",
    title: "Argument Essay",
    icon: "MessageSquare",
    subsections: [
      { id: "arg-overview", title: "Overview & Strategy", path: "/argument/overview" },
      { id: "thesis-formulas", title: "Thesis Formulas", path: "/argument/thesis" },
      { id: "evidence", title: "Evidence & Examples", path: "/argument/evidence" },
      { id: "arg-rubric", title: "Scoring Rubric", path: "/argument/rubric" }
    ]
  },
  {
    id: "synthesis",
    title: "Synthesis Essay",
    icon: "Link",
    subsections: [
      { id: "syn-overview", title: "Overview & Strategy", path: "/synthesis/overview" },
      { id: "source-integration", title: "Source Integration", path: "/synthesis/sources" },
      { id: "synthesis-tips", title: "Synthesis vs Summary", path: "/synthesis/tips" },
      { id: "syn-rubric", title: "Scoring Rubric", path: "/synthesis/rubric" }
    ]
  },
  {
    id: "mcq",
    title: "Multiple Choice",
    icon: "CheckSquare",
    subsections: [
      { id: "mcq-strategies", title: "Reading Strategies", path: "/mcq/strategies" },
      { id: "time-management", title: "Time Management", path: "/mcq/time" },
      { id: "common-traps", title: "Common Traps", path: "/mcq/traps" }
    ]
  },
  {
    id: "devices",
    title: "Rhetorical Devices",
    icon: "Sparkles",
    subsections: [
      { id: "appeals", title: "Rhetorical Appeals", path: "/devices/appeals" },
      { id: "syntax", title: "Syntax & Structure", path: "/devices/syntax" },
      { id: "figurative", title: "Figurative Language", path: "/devices/figurative" },
      { id: "all-devices", title: "Complete Library", path: "/devices/all" }
    ]
  },
  {
    id: "writing-tips",
    title: "Writing Tips",
    icon: "Lightbulb",
    subsections: [
      { id: "sophistication", title: "Sophistication Strategies", path: "/tips/sophistication" },
      { id: "syntax-variety", title: "Syntax Variety", path: "/tips/syntax" },
      { id: "transitions", title: "Transitions", path: "/tips/transitions" },
      { id: "pitfalls", title: "Common Pitfalls", path: "/tips/pitfalls" }
    ]
  },
  {
    id: "practice",
    title: "Practice Prompts",
    icon: "FileText",
    subsections: [
      { id: "practice-all", title: "All Prompts", path: "/practice/all" },
      { id: "practice-ra", title: "Rhetorical Analysis", path: "/practice/rhetorical-analysis" },
      { id: "practice-arg", title: "Argument", path: "/practice/argument" },
      { id: "practice-syn", title: "Synthesis", path: "/practice/synthesis" }
    ]
  },
  {
    id: "study-plan",
    title: "Study Schedule",
    icon: "Calendar",
    subsections: [
      { id: "3-month", title: "3-Month Plan", path: "/study/3-month" },
      { id: "2-month", title: "2-Month Plan", path: "/study/2-month" },
      { id: "1-month", title: "1-Month Plan", path: "/study/1-month" }
    ]
  },
  {
    id: "resources",
    title: "Quick Reference",
    icon: "Download",
    subsections: [
      { id: "cheat-sheets", title: "Cheat Sheets", path: "/resources/cheat-sheets" },
      { id: "tone-words", title: "Tone Words List", path: "/resources/tone-words" },
      { id: "analytical-verbs", title: "Analytical Verbs", path: "/resources/verbs" }
    ]
  }
];
