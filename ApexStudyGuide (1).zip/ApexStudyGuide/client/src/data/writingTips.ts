import { WritingTip } from "@shared/schema";

export const writingTips: WritingTip[] = [
  // Sophistication
  {
    id: "soph-01",
    category: "sophistication",
    title: "Qualify Your Claims",
    description: "Avoid absolute statements. Use qualifiers to show nuanced thinking and acknowledge complexity.",
    examples: [
      "Instead of: 'Technology always improves education'",
      "Write: 'Technology often enhances education when implemented thoughtfully'",
      "Qualifiers: often, typically, generally, in many cases, frequently, tends to, can, may"
    ]
  },
  {
    id: "soph-02",
    category: "sophistication",
    title: "Address Complexity and Nuance",
    description: "Acknowledge that issues have multiple dimensions. Show you understand competing perspectives.",
    examples: [
      "'While X offers benefits, it also presents challenges that require consideration'",
      "'Although the evidence supports Y, we must also account for Z'",
      "'This solution, despite its merits, may prove insufficient without addressing underlying factors'"
    ]
  },
  {
    id: "soph-03",
    category: "sophistication",
    title: "Make Connections Between Ideas",
    description: "Link your ideas explicitly. Show how points relate to each other and build toward your thesis.",
    examples: [
      "'Beyond the economic implications, this policy also affects social dynamics'",
      "'This evidence not only supports the claim but also reveals a broader pattern'",
      "'The consequences extend from individual behavior to systemic change'"
    ]
  },
  {
    id: "soph-04",
    category: "sophistication",
    title: "Use Subordinate Clauses",
    description: "Create complex sentences that show relationships between ideas rather than simple sentences stating facts.",
    examples: [
      "Simple: 'Schools need more funding. Students will benefit.'",
      "Complex: 'When schools receive adequate funding, students benefit from enhanced resources and opportunities'",
      "Use: although, because, while, whereas, if, when, since, unless"
    ]
  },
  {
    id: "soph-05",
    category: "sophistication",
    title: "Demonstrate Broader Implications",
    description: "Show why your argument matters beyond the specific case. Connect to larger themes and consequences.",
    examples: [
      "'This decision sets a precedent that could reshape how society approaches...'",
      "'The implications extend beyond education to questions of equity and opportunity'",
      "'Understanding this issue requires examining underlying assumptions about...'"
    ]
  },

  // Syntax Variety
  {
    id: "syn-01",
    category: "syntax",
    title: "Vary Sentence Openings",
    description: "Don't start every sentence with the subject. Use different opening structures for rhythm and interest.",
    examples: [
      "Prepositional phrase: 'In modern society, technology shapes daily interactions'",
      "Dependent clause: 'Although critics object, the evidence supports this conclusion'",
      "Participial phrase: 'Having examined the data, researchers concluded...'",
      "Adverb: 'Consequently, schools must reconsider their approach'",
      "Infinitive: 'To understand this phenomenon, we must examine its origins'"
    ]
  },
  {
    id: "syn-02",
    category: "syntax",
    title: "Mix Sentence Lengths",
    description: "Combine short, medium, and long sentences to create rhythm and emphasis.",
    examples: [
      "Long sentence for analysis: 'While technology offers unprecedented access to information and enables collaborative learning across distances, it also presents challenges including digital distractions and reduced face-to-face interaction skills'",
      "Medium sentence for transition: 'This complexity demands careful consideration'",
      "Short sentence for impact: 'The stakes are high'"
    ]
  },
  {
    id: "syn-03",
    category: "syntax",
    title: "Use Periodic Sentences",
    description: "Build suspense by placing the main clause at the end of the sentence.",
    examples: [
      "'Despite budget constraints, political opposition, and logistical challenges, the program succeeded'",
      "'After years of research, countless experiments, and numerous setbacks, scientists finally achieved a breakthrough'",
      "'Though critics warned of disaster and skeptics predicted failure, the initiative transformed the community'"
    ]
  },
  {
    id: "syn-04",
    category: "syntax",
    title: "Employ Parallelism",
    description: "Use parallel structure for related ideas to create rhythm and emphasis.",
    examples: [
      "'Education empowers individuals, strengthens communities, and transforms societies'",
      "'Students need not just information but also skills, not just knowledge but also wisdom'",
      "'The program aims to increase access, improve quality, and ensure equity'"
    ]
  },
  {
    id: "syn-05",
    category: "syntax",
    title: "Strategic Use of Semicolons",
    description: "Connect closely related independent clauses to show their relationship.",
    examples: [
      "'Technology offers unprecedented opportunities; it also presents unprecedented challenges'",
      "'Some argue for immediate action; others advocate for careful planning'",
      "'The data proves compelling; the implications demand attention'"
    ]
  },

  // Transitions
  {
    id: "trans-01",
    category: "transitions",
    title: "Addition and Emphasis",
    description: "Connect ideas that build on each other.",
    examples: [
      "Moreover, Furthermore, Additionally, In addition, Similarly, Likewise",
      "'Furthermore, this evidence demonstrates...'",
      "'Not only does this policy benefit students, but it also supports teachers'",
      "Use to: add supporting points, provide additional evidence, emphasize importance"
    ]
  },
  {
    id: "trans-02",
    category: "transitions",
    title: "Contrast and Concession",
    description: "Show opposing ideas or acknowledge counterarguments.",
    examples: [
      "However, Nevertheless, Nonetheless, On the other hand, Conversely, In contrast, Yet, Although, While",
      "'While critics raise valid concerns, the benefits outweigh the drawbacks'",
      "'The proposal has merit; however, implementation poses challenges'",
      "Use to: introduce counterarguments, show contrasts, qualify claims"
    ]
  },
  {
    id: "trans-03",
    category: "transitions",
    title: "Cause and Effect",
    description: "Show causal relationships between ideas.",
    examples: [
      "Therefore, Thus, Consequently, As a result, Because of this, Hence, Accordingly",
      "'Consequently, schools must adapt their curricula'",
      "'The data reveals clear patterns; therefore, policy changes are warranted'",
      "Use to: show logical results, connect evidence to claims, draw conclusions"
    ]
  },
  {
    id: "trans-04",
    category: "transitions",
    title: "Exemplification",
    description: "Introduce specific examples or evidence.",
    examples: [
      "For example, For instance, Specifically, In particular, To illustrate, Namely, Such as",
      "'For instance, students in year-round schools show reduced summer learning loss'",
      "'Specifically, the study examined three communities'",
      "Use to: provide concrete evidence, clarify abstract claims, support assertions"
    ]
  },
  {
    id: "trans-05",
    category: "transitions",
    title: "Sequencing and Organization",
    description: "Show the order or structure of your argument.",
    examples: [
      "First, Second, Third, Finally, Subsequently, Previously, Ultimately, In conclusion",
      "'First, we must examine the historical context'",
      "'Ultimately, these factors combine to create significant impact'",
      "Use to: organize multi-part arguments, guide readers through structure, build toward conclusion"
    ]
  },

  // Common Pitfalls
  {
    id: "pit-01",
    category: "pitfalls",
    title: "Avoid Plot Summary",
    description: "In rhetorical analysis, focus on HOW the author writes, not WHAT they say.",
    examples: [
      "Don't: 'King talks about justice and freedom in his letter'",
      "Do: 'King employs biblical allusions and parallel structure to establish his moral authority and create emotional resonance with his clergy audience'",
      "Every sentence should analyze rhetoric, not summarize content"
    ]
  },
  {
    id: "pit-02",
    category: "pitfalls",
    title: "Don't Just Identify Devices",
    description: "Name the device, show how it works, and explain WHY it's effective.",
    examples: [
      "Weak: 'Carson uses imagery'",
      "Better: 'Carson uses imagery to describe the town'",
      "Best: 'Carson employs vivid sensory imagery contrasting pastoral beauty with silent desolation to alarm readers about pesticides' devastating environmental impact'",
      "Always include: What + How + Why (effect/purpose)"
    ]
  },
  {
    id: "pit-03",
    category: "pitfalls",
    title: "Avoid Vague Language",
    description: "Use specific, precise language instead of generic descriptions.",
    examples: [
      "Vague: 'The author uses good evidence'",
      "Specific: 'The author cites peer-reviewed research and statistical data'",
      "Vague: 'This makes the reader feel emotions'",
      "Specific: 'This evokes sympathy and moral outrage in the audience'",
      "Be concrete: name specific strategies, emotions, and effects"
    ]
  },
  {
    id: "pit-04",
    category: "pitfalls",
    title: "Don't Overuse Quotes",
    description: "Use brief, strategic quotes. Your analysis should dominate, not quotations.",
    examples: [
      "Too much: [5-line quote] followed by 'This shows Carson cares about the environment'",
      "Better: 'Carson describes the town as having \"white granular powder\" that fell \"like snow,\" imagery that transforms pesticides into a deadly blizzard threatening all life'",
      "Integrate quotes smoothly into your sentences",
      "Follow every quote with substantial analysis"
    ]
  },
  {
    id: "pit-05",
    category: "pitfalls",
    title: "Avoid Weak Verbs",
    description: "Use strong, specific verbs that convey rhetorical action.",
    examples: [
      "Weak: uses, says, talks about, goes into, shows",
      "Strong: employs, crafts, juxtaposes, illuminates, underscores, establishes, evokes, challenges, refutes, champions",
      "'Carson employs' not 'Carson uses'",
      "'King establishes' not 'King shows'",
      "Strong verbs demonstrate analytical thinking"
    ]
  },
  {
    id: "pit-06",
    category: "pitfalls",
    title: "Stay in Present Tense",
    description: "Discuss texts in present tense, even for historical documents.",
    examples: [
      "Wrong: 'King wrote a letter where he argued for justice'",
      "Right: 'King writes a letter in which he argues for justice'",
      "Wrong: 'The author used imagery to convey...'",
      "Right: 'The author uses imagery to convey...'",
      "Literary/rhetorical present tense is standard convention"
    ]
  },
  {
    id: "pit-07",
    category: "pitfalls",
    title: "Avoid First and Second Person",
    description: "Use third person for academic tone (unless prompt specifically requests personal experience).",
    examples: [
      "Avoid: 'I think that technology helps students' or 'You can see that...'",
      "Better: 'Technology enhances student learning' or 'One can observe that...' or 'The evidence demonstrates...'",
      "Exception: Argument essays MAY use 'we' for inclusive rhetoric",
      "Exception: Personal narrative evidence can use first person"
    ]
  },
  {
    id: "pit-08",
    category: "pitfalls",
    title: "Don't State the Obvious",
    description: "Avoid pointing out obvious rhetorical intent without adding analysis.",
    examples: [
      "Obvious: 'The author writes this to persuade the audience'",
      "Analytical: 'The author employs emotional appeals to transform reader sympathy into support for policy reform'",
      "Obvious: 'The author wants readers to agree'",
      "Analytical: 'Through strategic concessions and counterargument refutation, the author builds credibility while systematically dismantling opposition'"
    ]
  },
  {
    id: "pit-09",
    category: "pitfalls",
    title: "Address the Prompt Directly",
    description: "Make sure your essay answers the specific question asked.",
    examples: [
      "If prompt asks about 'rhetorical strategies,' discuss multiple strategies",
      "If prompt asks about 'effectiveness,' evaluate success/impact",
      "If prompt specifies 'how the author develops argument,' focus on argument construction",
      "Reread prompt before writing conclusion to ensure full response"
    ]
  },
  {
    id: "pit-10",
    category: "pitfalls",
    title: "Manage Your Time",
    description: "Don't spend all your time on introduction or reading. Balance planning, writing, and revision.",
    examples: [
      "Rhetorical Analysis: 10min reading/planning, 25min writing, 5min revision",
      "Argument: 10min planning, 27min writing, 3min revision",
      "Synthesis: 15min reading period + 5min planning, 18min writing, 2min revision",
      "If running short on time: finish body paragraphs, write brief conclusion",
      "Brief conclusion better than none; incomplete body paragraphs hurt more"
    ]
  }
];
