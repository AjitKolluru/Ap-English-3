import { EssayTemplate } from "@shared/schema";

export const essayTemplates: EssayTemplate[] = [
  {
    id: "rhetorical-analysis-template",
    type: "rhetorical-analysis",
    title: "Rhetorical Analysis Essay Structure",
    timeAllocation: "40 minutes total",
    structure: [
      {
        section: "Reading & Planning",
        timeMinutes: 10,
        content: [
          "Read the passage twice: once for understanding, once for rhetorical strategies",
          "Annotate: Circle rhetorical devices, underline key claims, note tone shifts",
          "Identify: Speaker, occasion, audience, purpose, subject (SOAPS)",
          "Use SPACECAT: Speaker, Purpose, Audience, Context, Exigence, Choices, Appeals, Tone",
          "Plan thesis: Author + strong verb + rhetorical strategies + purpose",
          "Outline 3 body paragraphs with different strategies"
        ]
      },
      {
        section: "Introduction",
        timeMinutes: 5,
        content: [
          "Hook: Brief context about the text or issue (1-2 sentences)",
          "Introduce the text: Author, title, genre, subject (1-2 sentences)",
          "Thesis: '[Author] uses [strategy 1], [strategy 2], and [strategy 3] to [purpose]'",
          "Example: 'In her groundbreaking work Silent Spring, Rachel Carson employs vivid imagery, emotional appeals, and scientific evidence to convince readers of the devastating environmental impact of pesticides'",
          "Keep it concise—save time for analysis"
        ]
      },
      {
        section: "Body Paragraph 1",
        timeMinutes: 7,
        content: [
          "Topic sentence: Identify first rhetorical strategy and its purpose",
          "Evidence: Specific textual example (quote or paraphrase)",
          "Analysis: Explain HOW the strategy works and WHY it's effective",
          "Commentary: Connect to author's overall purpose and effect on audience",
          "Transition: Link to next strategy",
          "Formula: 'Carson opens with [strategy], as seen in [evidence], which serves to [effect] by [explanation]'"
        ]
      },
      {
        section: "Body Paragraph 2",
        timeMinutes: 7,
        content: [
          "Topic sentence: Identify second rhetorical strategy",
          "Evidence: Different textual example",
          "Analysis: Explain the strategy's function and effectiveness",
          "Commentary: Deepen analysis by discussing sophisticated effects (tone, relationship with audience)",
          "Transition: Prepare for final strategy",
          "Vary sentence structure from first body paragraph for sophistication"
        ]
      },
      {
        section: "Body Paragraph 3",
        timeMinutes: 7,
        content: [
          "Topic sentence: Identify third strategy or discuss cumulative effect",
          "Evidence: Final textual example",
          "Analysis: Explain how this strategy completes the rhetorical situation",
          "Commentary: Discuss the overall effectiveness and lasting impact",
          "Show how all strategies work together to achieve purpose",
          "Demonstrate sophisticated understanding of rhetoric"
        ]
      },
      {
        section: "Conclusion",
        timeMinutes: 4,
        content: [
          "Restate thesis in new words (avoid copy-paste)",
          "Synthesize: Briefly note how strategies work together",
          "Broader significance: Why does this rhetoric matter? What makes it effective?",
          "Strong final sentence that leaves an impression",
          "Keep it brief—2-4 sentences maximum",
          "NO NEW EVIDENCE in conclusion"
        ]
      }
    ],
    tips: [
      "Focus on the HOW and WHY, not just WHAT (don't just identify—analyze)",
      "Use active, analytical verbs: 'employs,' 'crafts,' 'utilizes,' 'juxtaposes'",
      "Avoid plot summary—every sentence should analyze rhetoric",
      "Quote strategically—brief, relevant quotes integrated smoothly",
      "Show sophistication through: complex sentences, nuanced understanding, linking strategies",
      "Proofread last 2-3 minutes for clarity and grammar"
    ]
  },
  {
    id: "argument-template",
    type: "argument",
    title: "Argument Essay Structure",
    timeAllocation: "40 minutes total",
    structure: [
      {
        section: "Planning",
        timeMinutes: 10,
        content: [
          "Read the prompt carefully—identify the issue and task",
          "Brainstorm: List 3-4 reasons supporting your position",
          "Gather evidence: Examples from history, literature, current events, personal observation",
          "Consider counterarguments and how to address them",
          "Develop clear thesis stating your position and preview main reasons",
          "Outline body paragraphs with one clear reason per paragraph"
        ]
      },
      {
        section: "Introduction",
        timeMinutes: 5,
        content: [
          "Hook: Compelling opening (question, anecdote, striking fact, quotation)",
          "Context: Explain the issue and why it matters (2-3 sentences)",
          "Thesis: Clear, defensible position with preview of main reasons",
          "Thesis formula: 'While [acknowledge opposition], [your position] because [reason 1], [reason 2], and [reason 3]'",
          "Example: 'While technology offers educational benefits, schools should limit classroom screen time because it diminishes critical thinking, reduces face-to-face collaboration, and creates attention problems'",
          "Make your position unmistakably clear"
        ]
      },
      {
        section: "Body Paragraph 1",
        timeMinutes: 7,
        content: [
          "Topic sentence: State first reason supporting your position",
          "Evidence: Specific, relevant example (historical, literary, contemporary, personal)",
          "Explanation: Analyze how evidence supports your claim",
          "Commentary: Connect to broader implications and your overall argument",
          "Line of reasoning: Show logical progression of ideas",
          "Formula: '[Reason] can be seen in [evidence], which demonstrates [explanation] and ultimately shows [significance]'"
        ]
      },
      {
        section: "Body Paragraph 2",
        timeMinutes: 7,
        content: [
          "Topic sentence: State second reason",
          "Evidence: Different type of evidence from first paragraph (vary sources)",
          "Explanation: Analyze the evidence thoroughly",
          "Commentary: Deepen argument with sophisticated reasoning",
          "Link to previous paragraph: 'Beyond [first reason], [second reason]...'",
          "Show complexity: qualify claims, acknowledge nuance"
        ]
      },
      {
        section: "Body Paragraph 3 or Counterargument",
        timeMinutes: 7,
        content: [
          "Option A: Third supporting reason (if argument is straightforward)",
          "Option B: Address counterargument (recommended for sophistication)",
          "Counterargument structure: 'Some argue [opposing view], and indeed [concede valid point]'",
          "Refutation: 'However, this overlooks [your response] because [reasoning]'",
          "Turn it back to support your thesis",
          "Shows sophisticated thinking and strengthens your argument"
        ]
      },
      {
        section: "Conclusion",
        timeMinutes: 4,
        content: [
          "Restate thesis with more sophisticated language",
          "Synthesize main reasons briefly",
          "Broader implications: Why does this issue matter? What's at stake?",
          "Call to action or thought-provoking final statement (optional)",
          "End with power—make it memorable",
          "3-5 sentences maximum"
        ]
      }
    ],
    tips: [
      "Take a clear position—don't be wishy-washy or fence-sit",
      "Use specific, detailed evidence (avoid vague generalities)",
      "Qualify claims for sophistication: 'often,' 'typically,' 'in many cases'",
      "Address complexity: acknowledge counterpoints and nuance",
      "Vary evidence types: historical examples, current events, literature, research, observation",
      "Show line of reasoning: make logical connections explicit",
      "Use topic sentences that clearly state each paragraph's point",
      "Demonstrate sophistication through: nuanced claims, counterarguments, complex sentences"
    ]
  },
  {
    id: "synthesis-template",
    type: "synthesis",
    title: "Synthesis Essay Structure",
    timeAllocation: "40 minutes total (includes 15min reading period)",
    structure: [
      {
        section: "Reading Period",
        timeMinutes: 15,
        content: [
          "Read the prompt first—understand the task and issue",
          "Skim all sources quickly—get overview of perspectives",
          "Re-read sources actively—annotate useful evidence and ideas",
          "Code sources: A, B, C, D, E, F for easy citation",
          "Note each source's main argument and useful evidence",
          "Plan which 3-4 sources you'll use (minimum 3 required)",
          "Develop your position on the issue",
          "Outline: thesis + which sources support each body paragraph"
        ]
      },
      {
        section: "Introduction",
        timeMinutes: 5,
        content: [
          "Hook: Engage reader with the issue's relevance",
          "Context: Explain the issue and controversy (synthesis of source perspectives)",
          "Thesis: Your position + preview of main reasons",
          "Thesis formula: 'While [acknowledge one perspective from sources], [your position] because [reason supported by sources 1], [reason supported by sources 2], and [reason supported by sources 3]'",
          "Show you understand multiple perspectives from sources",
          "Example: 'While some argue that urban green spaces are costly luxuries (Source B), cities must prioritize parks as essential infrastructure because they provide critical health benefits (Source A), strengthen community bonds (Source D), and deliver economic returns (Source F)'"
        ]
      },
      {
        section: "Body Paragraph 1",
        timeMinutes: 6,
        content: [
          "Topic sentence: First reason supporting your position",
          "Synthesize 2+ sources: weave together related ideas",
          "Cite sources in parentheses: (Source A) or (Source A, Source C)",
          "Don't just list sources—integrate them into your argument",
          "Explain how sources support your reasoning",
          "Add your own commentary beyond just summarizing sources",
          "Formula: 'Studies demonstrate [claim], with Source A showing [evidence] and Source C revealing [evidence], which together prove [your reasoning]'"
        ]
      },
      {
        section: "Body Paragraph 2",
        timeMinutes: 6,
        content: [
          "Topic sentence: Second reason",
          "Use different sources than Body 1 (can overlap one)",
          "Synthesize sources—show connections between them",
          "Integrate quotations smoothly with your analysis",
          "Explain significance of evidence",
          "Demonstrate that YOUR argument drives the essay, not the sources",
          "Sources should support YOUR claims, not replace them"
        ]
      },
      {
        section: "Body Paragraph 3",
        timeMinutes: 6,
        content: [
          "Topic sentence: Third reason OR counterargument with refutation",
          "Continue synthesizing sources to support your reasoning",
          "Show sophistication: acknowledge complexity, qualify claims",
          "If addressing counterargument: cite opposing source, then refute with other sources",
          "Ensure all paragraphs link back to thesis",
          "By end of this paragraph, should have cited at least 3 different sources total"
        ]
      },
      {
        section: "Conclusion",
        timeMinutes: 2,
        content: [
          "Restate thesis with sophisticated phrasing",
          "Briefly synthesize how sources support your position",
          "Broader implications or call to action",
          "Strong closing sentence",
          "Keep it concise—2-4 sentences",
          "End confidently"
        ]
      }
    ],
    tips: [
      "You MUST cite at least 3 sources (citing more shows sophistication)",
      "Integrate sources smoothly—don't just drop quotes",
      "Attribute ideas: 'According to Source A,' or 'As Source C demonstrates,'",
      "SYNTHESIZE, don't summarize—show connections between sources",
      "Your argument should lead; sources should support",
      "Avoid source strings: don't list all sources in one sentence without analysis",
      "Commentary is crucial—explain why sources matter to YOUR argument",
      "Cite format: (Source A), (Source B), or (Sources A and C)",
      "Use sources to support different aspects of your argument",
      "Show sophistication: acknowledge limitations, qualify claims, recognize nuance"
    ]
  }
];
