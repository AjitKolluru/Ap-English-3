import { PracticePrompt } from "@shared/schema";

export const practicePrompts: PracticePrompt[] = [
  // Rhetorical Analysis Prompts
  {
    id: "ra-01",
    type: "rhetorical-analysis",
    title: "Martin Luther King Jr. - Letter from Birmingham Jail (1963)",
    prompt: "In April 1963, Martin Luther King Jr. was arrested in Birmingham, Alabama, for participating in a nonviolent protest against segregation. While imprisoned, he wrote a letter responding to white clergymen who had criticized his actions as \"unwise and untimely.\" Read the passage carefully. Then, in a well-developed essay, analyze the rhetorical strategies King uses to defend his presence and actions in Birmingham and to advocate for the civil rights movement. Consider how King's strategic use of appeals, syntax, and figurative language strengthens his argument.",
    difficulty: "medium",
    theme: ["civil rights", "persuasion", "ethos"],
    sampleResponse: "In his 'Letter from Birmingham Jail,' Martin Luther King Jr. employs a masterful combination of ethical appeals, logical reasoning, and emotive language to justify the civil rights movement and his participation in it...",
    rubric: "Focus on: identification of rhetorical strategies, analysis of their effects, connection to King's purpose, and sophistication of argument."
  },
  {
    id: "ra-02",
    type: "rhetorical-analysis",
    title: "Rachel Carson - Silent Spring Opening (1962)",
    prompt: "Rachel Carson's groundbreaking environmental science book 'Silent Spring' begins with a fable about a town where all life has been silenced by the effects of pesticides. Read the opening chapter carefully. Then write an essay in which you analyze the rhetorical choices Carson makes to convey her message about environmental destruction. Consider her use of imagery, tone, and structure.",
    difficulty: "medium",
    theme: ["environment", "imagery", "tone"],
    sampleResponse: "Carson strategically opens with an idyllic pastoral scene that transforms into a dystopian nightmare, using vivid sensory imagery and carefully crafted contrasts to alarm readers...",
    rubric: "Analyze Carson's use of contrast, imagery, and tone shifts. Explain how these choices advance her environmental argument."
  },
  {
    id: "ra-03",
    type: "rhetorical-analysis",
    title: "Frederick Douglass - What to the Slave is the Fourth of July? (1852)",
    prompt: "In 1852, Frederick Douglass was invited to speak at an Independence Day celebration in Rochester, New York. His speech questioned the meaning of freedom in a nation that still practiced slavery. Read the excerpt from his speech carefully. Then, write an essay analyzing the rhetorical strategies Douglass uses to challenge his audience's celebration of freedom. Pay particular attention to his use of irony, rhetorical questions, and appeals.",
    difficulty: "hard",
    theme: ["freedom", "irony", "social justice"],
    sampleResponse: "Douglass employs biting irony and pointed rhetorical questions to expose the hypocrisy of celebrating freedom in a slaveholding nation...",
    rubric: "Strong analysis connects Douglass's rhetorical choices to his complex purpose of criticism while maintaining audience engagement."
  },
  {
    id: "ra-04",
    type: "rhetorical-analysis",
    title: "Sojourner Truth - Ain't I a Woman? (1851)",
    prompt: "At the 1851 Women's Rights Convention in Akron, Ohio, Sojourner Truth delivered an extemporaneous speech addressing both women's rights and racial inequality. Read the speech carefully. Then write an essay analyzing how Truth uses rhetorical strategies to argue for women's equality. Consider her use of repetition, personal narrative, and logical appeals.",
    difficulty: "medium",
    theme: ["women's rights", "equality", "anaphora"],
    sampleResponse: "Through the powerful anaphora 'Ain't I a woman?' Truth systematically dismantles arguments against women's equality by contrasting societal expectations with her lived experiences...",
    rubric: "Analyze how repetition, personal testimony, and logical reasoning work together to advance Truth's argument for equality."
  },
  {
    id: "ra-05",
    type: "rhetorical-analysis",
    title: "John F. Kennedy - Inaugural Address (1961)",
    prompt: "In his 1961 inaugural address, President John F. Kennedy sought to inspire Americans and address Cold War tensions. Read the speech carefully. Then write an essay analyzing the rhetorical strategies Kennedy uses to unite the nation and articulate his vision for America's role in the world. Consider his use of antithesis, parallelism, and appeals to shared values.",
    difficulty: "easy",
    theme: ["leadership", "unity", "parallelism"],
    sampleResponse: "Kennedy's masterful use of antithesis ('Ask not what your country can do for you—ask what you can do for your country') creates memorable, quotable phrases that inspire civic duty...",
    rubric: "Identify and analyze Kennedy's use of parallelism and balanced sentences. Explain how these contribute to his inspirational tone."
  },
  {
    id: "ra-06",
    type: "rhetorical-analysis",
    title: "George Orwell - Politics and the English Language (1946)",
    prompt: "In his essay 'Politics and the English Language,' George Orwell argues that unclear writing leads to unclear thinking and that political language is designed to obscure truth. Read the excerpt carefully. Then write an essay analyzing the rhetorical strategies Orwell employs to convince readers of the connection between language and thought. Consider his use of examples, tone, and structural choices.",
    difficulty: "hard",
    theme: ["language", "politics", "examples"],
    sampleResponse: "Orwell employs concrete examples of poor writing alongside his abstract arguments about language degradation, making his theoretical points tangible and convincing...",
    rubric: "Analyze how Orwell's examples, satirical tone, and logical structure support his argument about language and political thought."
  },

  // Argument Prompts
  {
    id: "arg-01",
    type: "argument",
    title: "Technology in Education",
    prompt: "Many educators argue that technology enhances learning through increased engagement and access to information, while others contend that it creates distractions and reduces critical thinking skills. Carefully read the following six sources, including the introductory information for each source. Then synthesize information from at least three of the sources and incorporate it into a coherent, well-developed essay that develops your position on whether schools should increase or limit technology use in classrooms. Make sure your argument is central; use the sources to support your reasoning. Avoid merely summarizing the sources.",
    difficulty: "medium",
    theme: ["education", "technology", "modern society"],
    sampleResponse: "While technology offers unprecedented access to information and collaborative tools, schools must implement structured limits to preserve deep thinking and genuine interpersonal skills...",
    rubric: "Develop a clear, defensible position. Use evidence effectively. Address counterarguments and demonstrate sophisticated thinking."
  },
  {
    id: "arg-02",
    type: "argument",
    title: "Social Media and Democracy",
    prompt: "Some argue that social media platforms strengthen democracy by giving voice to marginalized groups and enabling grassroots organization, while others claim these platforms undermine democratic discourse through echo chambers and misinformation. Write an essay that argues your position on the role of social media in democratic society. Support your argument with appropriate evidence and reasoning.",
    difficulty: "hard",
    theme: ["social media", "democracy", "communication"],
    sampleResponse: "Social media's democratization of information sharing fundamentally benefits society, though this power requires parallel investments in digital literacy and platform accountability...",
    rubric: "Present nuanced argument that acknowledges complexity. Use specific, relevant evidence. Demonstrate sophisticated understanding of the issue."
  },
  {
    id: "arg-03",
    type: "argument",
    title: "Universal Basic Income",
    prompt: "As automation threatens traditional employment, some economists propose universal basic income (UBI)—providing all citizens with regular, unconditional cash payments. Proponents argue it would reduce poverty and provide economic security, while critics claim it would discourage work and prove economically unsustainable. Develop an argument about whether governments should implement UBI programs. Support your position with evidence and logical reasoning.",
    difficulty: "hard",
    theme: ["economics", "policy", "future"],
    sampleResponse: "Universal basic income represents a necessary evolution in social policy as automation reshapes labor markets, providing economic stability while enabling individuals to pursue education and entrepreneurship...",
    rubric: "Take clear position on UBI. Provide economic and social evidence. Address counterarguments effectively. Show sophisticated reasoning."
  },
  {
    id: "arg-04",
    type: "argument",
    title: "Standardized Testing",
    prompt: "Standardized tests have long been used to measure student achievement and compare schools. Critics argue these tests narrow curriculum, increase stress, and disadvantage certain groups, while supporters claim they provide objective measures of learning and accountability. Develop an argument about the role standardized testing should play in education. Use appropriate evidence and examples to support your position.",
    difficulty: "medium",
    theme: ["education", "assessment", "equity"],
    sampleResponse: "While standardized tests provide valuable data points, education systems must shift toward portfolio-based assessments that capture student growth and diverse forms of intelligence...",
    rubric: "Clear position on testing. Use specific evidence. Consider multiple perspectives. Connect to broader educational goals."
  },
  {
    id: "arg-05",
    type: "argument",
    title: "Arts Education Funding",
    prompt: "Facing budget constraints, many schools have reduced or eliminated arts programs to focus resources on subjects tested under accountability measures. Advocates for arts education argue it develops creativity, cultural awareness, and cognitive skills, while others contend limited resources should prioritize core academic subjects. Write an essay arguing your position on funding for arts education in schools. Support your argument with appropriate evidence and reasoning.",
    difficulty: "easy",
    theme: ["education", "arts", "priorities"],
    sampleResponse: "Arts education deserves robust funding because it develops essential skills—creativity, collaboration, and cultural literacy—that prepare students for innovative problem-solving in all fields...",
    rubric: "Defend position with specific reasons. Use relevant evidence. Address budget concerns. Show clear line of reasoning."
  },
  {
    id: "arg-06",
    type: "argument",
    title: "Privacy vs. Security",
    prompt: "Following security threats, governments have expanded surveillance and data collection programs. This creates tension between public safety and individual privacy rights. Some argue that those with nothing to hide have nothing to fear, while others contend that privacy is a fundamental right essential to democracy. Develop an argument about how society should balance privacy and security concerns. Support your position with evidence and logical reasoning.",
    difficulty: "medium",
    theme: ["privacy", "security", "civil liberties"],
    sampleResponse: "Democratic societies must prioritize privacy protections even when confronting security threats, as unchecked surveillance historically enables authoritarian control and chills free expression...",
    rubric: "Take nuanced position on privacy/security balance. Use historical and contemporary evidence. Address competing values. Demonstrate sophistication."
  },
  {
    id: "arg-07",
    type: "argument",
    title: "College Admissions and Legacy Preferences",
    prompt: "Many selective colleges give preferential treatment to children of alumni (legacy admissions). Supporters argue this tradition builds institutional loyalty and supports fundraising, while critics claim it perpetuates inequality and contradicts merit-based principles. Develop an argument about whether colleges should continue legacy admission preferences. Use appropriate evidence to support your position.",
    difficulty: "medium",
    theme: ["education", "equity", "tradition"],
    sampleResponse: "Legacy admissions undermine educational equity and institutional integrity; colleges must eliminate these preferences to honor meritocratic principles and expand opportunity...",
    rubric: "Clear position on legacy admissions. Address equity and institutional arguments. Use specific evidence. Show sophisticated reasoning about competing values."
  },

  // Synthesis Prompts
  {
    id: "syn-01",
    type: "synthesis",
    title: "Public Libraries in the Digital Age",
    prompt: "As digital resources become increasingly available, some question whether physical libraries remain necessary. Others argue that libraries serve essential community functions beyond providing books. Carefully read the following six sources about the role of public libraries. Then synthesize information from at least three sources to develop and support your position on how communities should approach library funding and services in the digital age.",
    difficulty: "medium",
    theme: ["libraries", "community", "digital transformation"],
    sampleResponse: "While digitalization transforms information access, public libraries must evolve rather than close, serving as community hubs that address digital divides and provide spaces for civic engagement...",
    rubric: "Synthesize multiple sources effectively. Develop clear position. Use sources to support rather than dominate argument. Show understanding of complexity."
  },
  {
    id: "syn-02",
    type: "synthesis",
    title: "Urban Green Spaces",
    prompt: "As cities grow denser, urban planners debate how much land should be devoted to parks and green spaces versus housing and commercial development. Read the following sources about urban green spaces carefully. Then write an essay that synthesizes information from at least three sources to develop a position on how cities should prioritize green space in urban planning.",
    difficulty: "medium",
    theme: ["urban planning", "environment", "quality of life"],
    sampleResponse: "Cities must prioritize green spaces as essential infrastructure, not amenities, because these areas provide measurable health, environmental, and economic benefits that justify reduced development density...",
    rubric: "Integrate sources smoothly. Take clear position on green space. Connect evidence to claims. Demonstrate synthesis rather than summary."
  },
  {
    id: "syn-03",
    type: "synthesis",
    title: "School Start Times",
    prompt: "Research shows that teenagers' biological clocks shift, making early morning alertness difficult. Many advocate for later school start times to align with adolescent sleep patterns, while others cite logistical and financial challenges. Read the sources about school start times carefully. Then synthesize information from at least three sources to develop your position on whether high schools should implement later start times.",
    difficulty: "easy",
    theme: ["education", "health", "policy"],
    sampleResponse: "Despite logistical challenges, schools should implement later start times because research overwhelmingly demonstrates improved academic performance, mental health, and safety outcomes...",
    rubric: "Synthesize scientific and practical sources. Take clear position. Address counterarguments. Show understanding of trade-offs."
  },
  {
    id: "syn-04",
    type: "synthesis",
    title: "Artificial Intelligence in Healthcare",
    prompt: "AI systems now assist in medical diagnosis, drug development, and patient care. While some celebrate these advances as revolutionary, others worry about algorithmic bias, privacy concerns, and the dehumanization of medicine. Read the sources about AI in healthcare carefully. Then synthesize information from at least three sources to develop your position on how the medical field should integrate AI technologies.",
    difficulty: "hard",
    theme: ["technology", "healthcare", "ethics"],
    sampleResponse: "Healthcare systems should cautiously integrate AI as a diagnostic support tool while maintaining human oversight, because algorithmic insights enhance accuracy without replacing the irreplaceable human elements of compassionate care...",
    rubric: "Synthesize technical and ethical sources. Take nuanced position. Address multiple perspectives. Demonstrate sophisticated understanding of complex issue."
  },
  {
    id: "syn-05",
    type: "synthesis",
    title: "Mandatory Community Service for Graduation",
    prompt: "Some schools require students to complete community service hours to graduate, arguing it builds character and civic responsibility. Critics contend that mandating service contradicts volunteerism's spirit and creates logistical burdens. Read the sources about mandatory community service carefully. Then synthesize information from at least three sources to develop your position on whether high schools should require community service for graduation.",
    difficulty: "medium",
    theme: ["education", "service", "character development"],
    sampleResponse: "Schools should require community service because structured programs successfully cultivate lifelong civic engagement, though implementations must ensure equitable access and authentic learning experiences...",
    rubric: "Synthesize educational and philosophical sources. Take clear position. Use specific examples from sources. Address both benefits and implementation concerns."
  },
  {
    id: "syn-06",
    type: "synthesis",
    title: "Year-Round Schooling",
    prompt: "Traditional summer breaks originated from agricultural calendars and may no longer serve modern society's needs. Some advocate for year-round schooling with shorter, more frequent breaks, while others defend traditional schedules. Read the sources about year-round schooling carefully. Then synthesize information from at least three sources to develop your position on whether schools should adopt year-round calendars.",
    difficulty: "easy",
    theme: ["education", "tradition", "reform"],
    sampleResponse: "Schools should transition to year-round calendars with strategic breaks because this structure reduces summer learning loss and provides needed rest intervals, though implementation requires addressing family and community concerns...",
    rubric: "Synthesize educational research and practical considerations. Take clear position. Address multiple stakeholder perspectives. Use sources effectively."
  },
  {
    id: "syn-07",
    type: "synthesis",
    title: "Single-Use Plastic Bans",
    prompt: "Many cities and countries have banned single-use plastics to reduce environmental pollution. While supporters praise these efforts as essential environmental protection, critics argue the bans create economic hardship and may have unintended consequences. Read the sources about plastic bans carefully. Then synthesize information from at least three sources to develop your position on whether governments should ban single-use plastics.",
    difficulty: "medium",
    theme: ["environment", "policy", "sustainability"],
    sampleResponse: "Governments should implement phased single-use plastic bans while investing in sustainable alternatives and supporting affected industries, because environmental urgency demands action despite economic disruptions...",
    rubric: "Synthesize environmental and economic sources. Take position that addresses complexity. Use sources to support nuanced argument. Demonstrate sophisticated reasoning."
  }
];
