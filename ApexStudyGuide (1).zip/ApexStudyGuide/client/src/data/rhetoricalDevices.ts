import { RhetoricalDevice } from "@shared/schema";

export const rhetoricalDevices: RhetoricalDevice[] = [
  // Appeals
  {
    id: "ethos",
    term: "Ethos",
    definition: "Appeal to credibility, authority, or ethical character of the speaker",
    effect: "Establishes trustworthiness and expertise, making the audience more receptive to the argument",
    example: "As a practicing physician for 20 years, I can confidently state that preventive care saves lives.",
    category: "appeals"
  },
  {
    id: "pathos",
    term: "Pathos",
    definition: "Appeal to emotions, values, desires, hopes, or fears of the audience",
    effect: "Creates emotional connection and motivates action through feelings rather than logic",
    example: "Imagine a world where no child goes to bed hungry—we have the power to make this a reality.",
    category: "appeals"
  },
  {
    id: "logos",
    term: "Logos",
    definition: "Appeal to logic, reason, and rational argument using evidence and facts",
    effect: "Convinces through logical reasoning and credible evidence, appealing to rationality",
    example: "Studies show that 85% of students who study consistently for 30 minutes daily improve their grades by at least one letter.",
    category: "appeals"
  },
  {
    id: "kairos",
    term: "Kairos",
    definition: "Appeal to timeliness and appropriateness of the moment",
    effect: "Creates urgency and relevance by emphasizing why action must be taken now",
    example: "With climate change accelerating at unprecedented rates, we cannot afford to wait another decade to act.",
    category: "appeals"
  },
  
  // Syntax
  {
    id: "parallelism",
    term: "Parallelism",
    definition: "Repetition of grammatical structures in successive phrases or clauses",
    effect: "Creates rhythm, emphasizes ideas, and makes arguments more memorable and persuasive",
    example: "We shall fight on the beaches, we shall fight on the landing grounds, we shall fight in the fields.",
    category: "syntax"
  },
  {
    id: "anaphora",
    term: "Anaphora",
    definition: "Repetition of the same word or phrase at the beginning of successive clauses",
    effect: "Emphasizes key ideas and creates rhythmic, memorable passages that build momentum",
    example: "I have a dream that one day... I have a dream that my four children... I have a dream today.",
    category: "syntax"
  },
  {
    id: "epistrophe",
    term: "Epistrophe",
    definition: "Repetition of the same word or phrase at the end of successive clauses",
    effect: "Reinforces ideas and creates a sense of inevitability or conclusion",
    example: "When I was a child, I spoke as a child, I understood as a child, I thought as a child.",
    category: "syntax"
  },
  {
    id: "antithesis",
    term: "Antithesis",
    definition: "Juxtaposition of contrasting ideas in balanced phrases or clauses",
    effect: "Highlights stark contrasts and emphasizes differences to strengthen arguments",
    example: "That's one small step for man, one giant leap for mankind.",
    category: "syntax"
  },
  {
    id: "chiasmus",
    term: "Chiasmus",
    definition: "Reversal of grammatical structures in successive phrases (AB BA pattern)",
    effect: "Creates memorable, quotable phrases and emphasizes the relationship between ideas",
    example: "Ask not what your country can do for you—ask what you can do for your country.",
    category: "syntax"
  },
  {
    id: "asyndeton",
    term: "Asyndeton",
    definition: "Omission of conjunctions between words, phrases, or clauses",
    effect: "Creates urgency, speeds up rhythm, and suggests accumulation or overwhelming quantity",
    example: "I came, I saw, I conquered.",
    category: "syntax"
  },
  {
    id: "polysyndeton",
    term: "Polysyndeton",
    definition: "Use of multiple conjunctions in close succession",
    effect: "Slows down rhythm, emphasizes each item, creates sense of accumulation or infinity",
    example: "We have ships and men and money and stores.",
    category: "syntax"
  },
  {
    id: "rhetorical-question",
    term: "Rhetorical Question",
    definition: "Question asked for effect, not expecting an answer",
    effect: "Engages audience, emphasizes a point, and implies the answer is obvious",
    example: "If we can't afford to educate our children, what kind of future are we building?",
    category: "syntax"
  },
  {
    id: "periodic-sentence",
    term: "Periodic Sentence",
    definition: "Sentence in which the main clause comes at the end",
    effect: "Builds suspense and emphasizes the conclusion by delaying the main point",
    example: "Despite the rain, the cold, and the darkness, we persevered.",
    category: "syntax"
  },
  {
    id: "cumulative-sentence",
    term: "Cumulative Sentence",
    definition: "Sentence that starts with main clause, then adds subordinate elements",
    effect: "Creates natural, flowing rhythm and allows for detailed elaboration",
    example: "The cat jumped, landing softly on the windowsill, tail twitching with anticipation.",
    category: "syntax"
  },
  {
    id: "zeugma",
    term: "Zeugma",
    definition: "Use of a word to modify two or more words in different senses",
    effect: "Creates wit, surprise, and economical expression",
    example: "She lost her heart and her wallet to the city.",
    category: "syntax"
  },
  
  // Figurative Language
  {
    id: "metaphor",
    term: "Metaphor",
    definition: "Direct comparison between two unlike things without using 'like' or 'as'",
    effect: "Creates vivid imagery and deeper understanding by comparing abstract to concrete",
    example: "Time is a thief that steals our youth.",
    category: "figurative"
  },
  {
    id: "simile",
    term: "Simile",
    definition: "Comparison using 'like' or 'as'",
    effect: "Makes descriptions more vivid and relatable through explicit comparison",
    example: "Her smile was like sunshine breaking through storm clouds.",
    category: "figurative"
  },
  {
    id: "personification",
    term: "Personification",
    definition: "Attribution of human characteristics to non-human things",
    effect: "Makes abstract concepts tangible and creates emotional connection",
    example: "The wind whispered secrets through the trees.",
    category: "figurative"
  },
  {
    id: "hyperbole",
    term: "Hyperbole",
    definition: "Deliberate exaggeration for emphasis or effect",
    effect: "Emphasizes point dramatically and creates memorable impressions",
    example: "I've told you a million times not to exaggerate.",
    category: "figurative"
  },
  {
    id: "understatement",
    term: "Understatement (Meiosis)",
    definition: "Deliberate downplaying of a situation's seriousness",
    effect: "Creates irony, humor, or emphasizes through contrast with reality",
    example: "The 1906 San Francisco earthquake was somewhat inconvenient.",
    category: "figurative"
  },
  {
    id: "irony",
    term: "Irony",
    definition: "Contrast between expectation and reality, or between what is said and meant",
    effect: "Creates layers of meaning, humor, or emphasizes absurdity of situations",
    example: "The fire station burned down (situational irony).",
    category: "figurative"
  },
  {
    id: "allusion",
    term: "Allusion",
    definition: "Reference to well-known person, place, event, literary work, or work of art",
    effect: "Adds depth and connects to broader cultural knowledge efficiently",
    example: "His Achilles heel was his inability to accept criticism.",
    category: "figurative"
  },
  {
    id: "symbolism",
    term: "Symbolism",
    definition: "Use of symbols to represent ideas or qualities beyond literal meaning",
    effect: "Adds layers of meaning and creates deeper thematic connections",
    example: "The green light in The Great Gatsby represents Gatsby's hopes and dreams.",
    category: "figurative"
  },
  {
    id: "imagery",
    term: "Imagery",
    definition: "Descriptive language that appeals to the senses",
    effect: "Creates vivid mental pictures and emotional responses",
    example: "The crimson sunset painted the sky, while salt-tinged breezes carried distant laughter.",
    category: "figurative"
  },
  {
    id: "analogy",
    term: "Analogy",
    definition: "Extended comparison between two different things",
    effect: "Clarifies complex ideas by comparing to familiar concepts",
    example: "The brain is like a computer: it processes information, stores memories, and can be upgraded with new software (learning).",
    category: "figurative"
  },
  {
    id: "metonymy",
    term: "Metonymy",
    definition: "Substitution of the name of an attribute or adjunct for that of the thing meant",
    effect: "Creates concise, evocative expression",
    example: "The White House announced new policies (White House = President/Administration).",
    category: "figurative"
  },
  {
    id: "synecdoche",
    term: "Synecdoche",
    definition: "Part represents the whole, or whole represents the part",
    effect: "Creates concise expression and emphasizes specific aspects",
    example: "All hands on deck (hands = sailors).",
    category: "figurative"
  },
  {
    id: "oxymoron",
    term: "Oxymoron",
    definition: "Combination of contradictory or incongruous words",
    effect: "Creates paradox and highlights complexity or irony",
    example: "Deafening silence, bitter sweet, living dead.",
    category: "figurative"
  },
  {
    id: "paradox",
    term: "Paradox",
    definition: "Statement that appears self-contradictory but reveals a deeper truth",
    effect: "Challenges thinking and reveals complex truths",
    example: "Less is more. War is peace. The more you know, the more you realize you don't know.",
    category: "figurative"
  },
  
  // Diction
  {
    id: "connotation",
    term: "Connotation",
    definition: "Emotional or cultural associations beyond literal meaning",
    effect: "Shapes audience perception and emotional response to language",
    example: "'Home' (positive connotation) vs. 'house' (neutral) vs. 'dwelling' (formal/cold).",
    category: "diction"
  },
  {
    id: "denotation",
    term: "Denotation",
    definition: "Literal, dictionary definition of a word",
    effect: "Provides precise, objective meaning",
    example: "Snake: a limbless reptile with a long, cylindrical body.",
    category: "diction"
  },
  {
    id: "diction-formal",
    term: "Formal Diction",
    definition: "Sophisticated, elevated language with complex vocabulary",
    effect: "Establishes authority, seriousness, and intellectual tone",
    example: "The individual's cognitive faculties were significantly compromised.",
    category: "diction"
  },
  {
    id: "diction-informal",
    term: "Informal Diction",
    definition: "Casual, conversational language",
    effect: "Creates relatability and accessibility",
    example: "The guy wasn't thinking straight.",
    category: "diction"
  },
  {
    id: "diction-colloquial",
    term: "Colloquial Diction",
    definition: "Everyday language including slang and regional expressions",
    effect: "Establishes authenticity and connects with specific audiences",
    example: "Y'all come back now, ya hear?",
    category: "diction"
  },
  {
    id: "jargon",
    term: "Jargon",
    definition: "Specialized vocabulary of a particular field or group",
    effect: "Establishes expertise but can exclude outsiders",
    example: "The patient exhibited tachycardia and dyspnea (medical jargon).",
    category: "diction"
  },
  {
    id: "abstract-language",
    term: "Abstract Language",
    definition: "Language referring to ideas, concepts, and qualities",
    effect: "Discusses complex philosophical or emotional concepts",
    example: "Justice, freedom, love, democracy.",
    category: "diction"
  },
  {
    id: "concrete-language",
    term: "Concrete Language",
    definition: "Language referring to specific, tangible things",
    effect: "Creates clarity and vivid mental images",
    example: "The red brick house, the smell of fresh bread, the sound of rain.",
    category: "diction"
  },
  
  // Other Important Devices
  {
    id: "tone",
    term: "Tone",
    definition: "Author's attitude toward subject and audience",
    effect: "Shapes reader's emotional response and interpretation",
    example: "Sarcastic, serious, humorous, melancholic, optimistic, critical.",
    category: "other"
  },
  {
    id: "mood",
    term: "Mood",
    definition: "Emotional atmosphere created for the reader",
    effect: "Influences reader's emotional experience of the text",
    example: "Suspenseful, peaceful, tense, joyful, ominous.",
    category: "other"
  },
  {
    id: "juxtaposition",
    term: "Juxtaposition",
    definition: "Placement of contrasting elements side by side",
    effect: "Highlights differences and creates emphasis through contrast",
    example: "Placing a scene of wealth next to one of poverty to emphasize inequality.",
    category: "other"
  },
  {
    id: "alliteration",
    term: "Alliteration",
    definition: "Repetition of initial consonant sounds in nearby words",
    effect: "Creates rhythm, emphasis, and memorable phrases",
    example: "Peter Piper picked a peck of pickled peppers.",
    category: "other"
  },
  {
    id: "assonance",
    term: "Assonance",
    definition: "Repetition of vowel sounds in nearby words",
    effect: "Creates internal rhyme and musicality",
    example: "The rain in Spain stays mainly in the plain.",
    category: "other"
  },
  {
    id: "consonance",
    term: "Consonance",
    definition: "Repetition of consonant sounds in nearby words",
    effect: "Creates subtle sound patterns and emphasis",
    example: "Pitter patter, all mammals named Sam are clammy.",
    category: "other"
  },
  {
    id: "onomatopoeia",
    term: "Onomatopoeia",
    definition: "Words that imitate the sounds they describe",
    effect: "Creates vivid sensory experience and immediacy",
    example: "Buzz, hiss, crackle, boom, whisper.",
    category: "other"
  },
  {
    id: "euphemism",
    term: "Euphemism",
    definition: "Mild or indirect word substituted for one considered harsh or blunt",
    effect: "Softens impact or makes uncomfortable topics more palatable",
    example: "'Passed away' instead of 'died', 'let go' instead of 'fired'.",
    category: "other"
  },
  {
    id: "aphorism",
    term: "Aphorism",
    definition: "Concise statement of a truth or principle",
    effect: "Provides memorable, quotable wisdom",
    example: "Actions speak louder than words.",
    category: "other"
  },
  {
    id: "satire",
    term: "Satire",
    definition: "Use of humor, irony, or exaggeration to criticize or expose",
    effect: "Critiques societal issues while entertaining",
    example: "Jonathan Swift's 'A Modest Proposal' satirizes British treatment of Irish poor.",
    category: "other"
  },
  {
    id: "understatement-litotes",
    term: "Litotes",
    definition: "Understatement using double negative or denial of opposite",
    effect: "Creates emphasis through ironic understatement",
    example: "He's not the sharpest tool in the shed (meaning he's quite dull).",
    category: "other"
  }
];
