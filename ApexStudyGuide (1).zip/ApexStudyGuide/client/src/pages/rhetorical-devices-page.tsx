import { useState, useMemo } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Search, Sparkles } from "lucide-react";
import { rhetoricalDevices } from "@/data/rhetoricalDevices";

export default function RhetoricalDevicesPage() {
  const [searchQuery, setSearchQuery] = useState("");
  const [activeCategory, setActiveCategory] = useState<string>("all");

  const categories = [
    { id: "all", label: "All Devices", count: rhetoricalDevices.length },
    { id: "appeals", label: "Rhetorical Appeals", count: rhetoricalDevices.filter(d => d.category === "appeals").length },
    { id: "syntax", label: "Syntax & Structure", count: rhetoricalDevices.filter(d => d.category === "syntax").length },
    { id: "figurative", label: "Figurative Language", count: rhetoricalDevices.filter(d => d.category === "figurative").length },
    { id: "diction", label: "Diction", count: rhetoricalDevices.filter(d => d.category === "diction").length },
    { id: "other", label: "Other Devices", count: rhetoricalDevices.filter(d => d.category === "other").length }
  ];

  const filteredDevices = useMemo(() => {
    return rhetoricalDevices.filter(device => {
      const matchesSearch = searchQuery === "" || 
        device.term.toLowerCase().includes(searchQuery.toLowerCase()) ||
        device.definition.toLowerCase().includes(searchQuery.toLowerCase()) ||
        device.effect.toLowerCase().includes(searchQuery.toLowerCase());
      
      const matchesCategory = activeCategory === "all" || device.category === activeCategory;
      
      return matchesSearch && matchesCategory;
    });
  }, [searchQuery, activeCategory]);

  return (
    <div className="max-w-6xl mx-auto px-6 py-12">
      <div className="mb-8">
        <Badge variant="secondary" className="mb-4">Rhetorical Devices</Badge>
        <h1 className="text-4xl md:text-5xl font-bold mb-4 flex items-center gap-3" data-testid="heading-devices">
          <Sparkles className="h-10 w-10 text-primary" />
          Complete Rhetorical Devices Library
        </h1>
        <p className="text-lg text-muted-foreground leading-relaxed max-w-3xl">
          Master 50+ essential rhetorical devices with definitions, effects, and real AP exam examples. Understanding these devices is crucial for rhetorical analysis essays and recognizing persuasive techniques.
        </p>
      </div>

      {/* Search Bar */}
      <div className="mb-8">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
          <Input
            type="search"
            placeholder="Search devices by name, definition, or effect..."
            className="pl-10 h-12 text-base"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            data-testid="input-search-devices"
          />
        </div>
      </div>

      {/* Category Tabs */}
      <Tabs value={activeCategory} onValueChange={setActiveCategory} className="mb-8">
        <TabsList className="flex flex-wrap h-auto gap-2 bg-transparent justify-start">
          {categories.map(category => (
            <TabsTrigger 
              key={category.id} 
              value={category.id}
              className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground"
              data-testid={`tab-category-${category.id}`}
            >
              {category.label}
              <Badge variant="secondary" className="ml-2 text-xs">
                {category.count}
              </Badge>
            </TabsTrigger>
          ))}
        </TabsList>
      </Tabs>

      {/* Results Count */}
      <div className="mb-6">
        <p className="text-sm text-muted-foreground" data-testid="text-results-count">
          Showing {filteredDevices.length} {filteredDevices.length === 1 ? 'device' : 'devices'}
        </p>
      </div>

      {/* Devices Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {filteredDevices.map((device) => (
          <Card key={device.id} className="hover-elevate" data-testid={`card-device-${device.id}`}>
            <CardHeader>
              <div className="flex items-start justify-between gap-4 mb-2">
                <CardTitle className="text-2xl">{device.term}</CardTitle>
                <Badge variant="outline" className="shrink-0 capitalize">
                  {device.category}
                </Badge>
              </div>
              <CardDescription className="text-base leading-relaxed">
                {device.definition}
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <h4 className="font-semibold text-sm mb-2 text-primary">Effect:</h4>
                <p className="text-sm text-muted-foreground leading-relaxed">
                  {device.effect}
                </p>
              </div>
              <div className="bg-muted/50 p-4 rounded-md">
                <h4 className="font-semibold text-sm mb-2">Example:</h4>
                <p className="text-sm italic leading-relaxed">
                  {device.example}
                </p>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {filteredDevices.length === 0 && (
        <Card className="text-center py-12">
          <CardContent>
            <Search className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
            <p className="text-lg font-medium mb-2">No devices found</p>
            <p className="text-muted-foreground">
              Try adjusting your search or selecting a different category
            </p>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
