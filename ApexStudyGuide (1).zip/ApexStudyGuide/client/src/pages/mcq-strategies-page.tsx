import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { CheckSquare, Clock, BookOpen, Target, AlertTriangle, Lightbulb } from "lucide-react";

export default function MCQStrategiesPage() {
  const readingStrategies = [
    {
      title: "Active Reading Approach",
      description: "Engage with the passage actively rather than passively consuming words",
      tips: [
        "Read the first and last paragraphs carefully—they often contain thesis and conclusion",
        "Underline key claims and circle transition words",
        "Note the author's tone and purpose in margins",
        "Identify the rhetorical situation (who, what, when, where, why)"
      ]
    },
    {
      title: "Question-First Strategy",
      description: "For difficult passages, scan questions before reading to know what to look for",
      tips: [
        "Quickly read all questions to identify what's being tested",
        "Note line references and specific elements mentioned in questions",
        "Read the passage with these focal points in mind",
        "Don't use this for easier passages—it wastes time"
      ]
    },
    {
      title: "Annotation Techniques",
      description: "Mark up the passage strategically to track important elements",
      tips: [
        "Bracket main claims and thesis statements",
        "Circle rhetorical devices and appeals",
        "Star surprising or pivotal moments",
        "Use margin notes for quick summaries of each paragraph's purpose"
      ]
    }
  ];

  const timeManagement = [
    {
      time: "~13 minutes per passage",
      breakdown: [
        "5-6 minutes: Read passage actively and annotate",
        "7-8 minutes: Answer all questions (45-60 seconds per question)",
        "Leave difficult questions for second pass"
      ]
    }
  ];

  const questionTypes = [
    {
      type: "Main Idea / Purpose",
      description: "Identify the overall point or author's primary goal",
      strategy: "Focus on introduction, conclusion, and repeated concepts. The answer should encompass the entire passage, not just one paragraph.",
      traps: "Choices that are too narrow (only one paragraph) or too broad (not specific to this passage)"
    },
    {
      type: "Rhetorical Strategy",
      description: "Identify how the author achieves their purpose",
      strategy: "Look for specific devices, appeals, organizational patterns. Consider WHY the author made this choice.",
      traps: "Identifying a strategy that exists but doesn't match the lines referenced"
    },
    {
      type: "Tone / Attitude",
      description: "Determine the author's attitude toward the subject",
      strategy: "Examine diction (word choice), especially adjectives and verbs. Consider overall feeling conveyed.",
      traps: "Extreme emotions that aren't supported, or confusing tone with subject matter (passage about sad topic ≠ sad tone)"
    },
    {
      type: "Function of a Word/Phrase",
      description: "Explain why the author included specific language",
      strategy: "Read the sentence before and after for context. Consider how it advances the argument or affects the reader.",
      traps: "Literal meaning instead of rhetorical function"
    },
    {
      type: "Inference / Implication",
      description: "Draw logical conclusions based on passage evidence",
      strategy: "The answer must be supported by passage evidence but won't be stated explicitly. Avoid assumptions or outside knowledge.",
      traps: "Bringing in outside information or making unsupported leaps"
    }
  ];

  const commonTraps = [
    {
      trap: "Extreme Language",
      description: "Answers with 'always,' 'never,' 'only,' 'must' are usually wrong",
      example: "If passage discusses benefits of technology, answer saying technology 'always improves learning' is too extreme"
    },
    {
      trap: "Partial Truths",
      description: "Answer may be true for part of the passage but doesn't address the whole question",
      example: "For a main idea question, choosing an answer that only describes paragraph 2"
    },
    {
      trap: "Outside Knowledge",
      description: "Using facts you know rather than what the passage actually says",
      example: "Choosing answer based on historical facts not mentioned in the passage"
    },
    {
      trap: "Word Traps",
      description: "Answer uses words from the passage but in wrong context or meaning",
      example: "Answer includes key terms from passage but misrepresents their relationship"
    },
    {
      trap: "Opposite Answers",
      description: "Answer says the reverse of what passage states",
      example: "If passage criticizes policy, answer says author supports it"
    }
  ];

  return (
    <div className="max-w-5xl mx-auto px-6 py-12">
      <div className="mb-8">
        <Badge variant="secondary" className="mb-4">Multiple Choice Strategies</Badge>
        <h1 className="text-4xl md:text-5xl font-bold mb-4 flex items-center gap-3" data-testid="heading-mcq-strategies">
          <CheckSquare className="h-10 w-10 text-primary" />
          MCQ Strategies & Techniques
        </h1>
        <p className="text-lg text-muted-foreground leading-relaxed max-w-3xl">
          Master the multiple choice section with proven reading strategies, time management techniques, and trap avoidance methods. The MCQ section accounts for 45% of your score.
        </p>
      </div>

      {/* Time Management */}
      <Card className="mb-8 bg-primary/5">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Clock className="h-5 w-5 text-primary" />
            Time Management
          </CardTitle>
          <CardDescription>1 hour for 45 questions across 4-5 passages</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="bg-background p-4 rounded-md border">
              <h4 className="font-semibold mb-3">Recommended Pacing:</h4>
              <div className="space-y-3">
                <div>
                  <p className="font-medium text-sm mb-2">~13 minutes per passage</p>
                  <ul className="space-y-2 text-sm text-muted-foreground ml-4">
                    <li className="flex items-start gap-2">
                      <div className="h-2 w-2 rounded-full bg-primary shrink-0 mt-2" />
                      <span>5-6 minutes: Read passage actively with annotations</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <div className="h-2 w-2 rounded-full bg-primary shrink-0 mt-2" />
                      <span>7-8 minutes: Answer questions (45-60 seconds each)</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <div className="h-2 w-2 rounded-full bg-primary shrink-0 mt-2" />
                      <span>Skip difficult questions on first pass, return with remaining time</span>
                    </li>
                  </ul>
                </div>
                <div className="bg-chart-4/10 text-chart-4 p-3 rounded-md">
                  <p className="font-medium text-sm mb-1">Pro Tip:</p>
                  <p className="text-sm">Aim to finish with 5-10 minutes remaining to review flagged questions. Don't leave any blank—there's no penalty for guessing!</p>
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Reading Strategies */}
      <div className="mb-8">
        <h2 className="text-2xl font-bold mb-6 flex items-center gap-2">
          <BookOpen className="h-6 w-6 text-primary" />
          Reading Strategies
        </h2>
        <div className="grid gap-6">
          {readingStrategies.map((strategy, index) => (
            <Card key={index} className="hover-elevate">
              <CardHeader>
                <CardTitle className="text-xl">{strategy.title}</CardTitle>
                <CardDescription className="text-base">{strategy.description}</CardDescription>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2">
                  {strategy.tips.map((tip, tipIndex) => (
                    <li key={tipIndex} className="flex items-start gap-2 text-sm text-muted-foreground">
                      <div className="h-2 w-2 rounded-full bg-chart-2 shrink-0 mt-2" />
                      <span>{tip}</span>
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>

      {/* Question Types */}
      <div className="mb-8">
        <h2 className="text-2xl font-bold mb-6 flex items-center gap-2">
          <Target className="h-6 w-6 text-primary" />
          Common Question Types & Strategies
        </h2>
        <div className="grid gap-6">
          {questionTypes.map((qt, index) => (
            <Card key={index} className="hover-elevate">
              <CardHeader>
                <CardTitle className="text-lg">{qt.type}</CardTitle>
                <CardDescription className="text-base">{qt.description}</CardDescription>
              </CardHeader>
              <CardContent className="space-y-3">
                <div>
                  <h4 className="font-semibold text-sm mb-2 text-chart-2">Strategy:</h4>
                  <p className="text-sm text-muted-foreground leading-relaxed">{qt.strategy}</p>
                </div>
                <div className="bg-destructive/10 p-3 rounded-md">
                  <h4 className="font-semibold text-sm mb-2 text-destructive">Common Traps:</h4>
                  <p className="text-sm text-muted-foreground leading-relaxed">{qt.traps}</p>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>

      {/* Common Traps */}
      <div className="mb-8">
        <h2 className="text-2xl font-bold mb-6 flex items-center gap-2">
          <AlertTriangle className="h-6 w-6 text-destructive" />
          Avoid These Common Traps
        </h2>
        <div className="grid gap-4">
          {commonTraps.map((item, index) => (
            <Card key={index} className="border-l-4 border-l-destructive">
              <CardHeader>
                <CardTitle className="text-lg">{item.trap}</CardTitle>
                <CardDescription className="text-base">{item.description}</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="bg-muted/50 p-3 rounded-md">
                  <p className="text-sm text-muted-foreground">
                    <span className="font-medium">Example: </span>{item.example}
                  </p>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>

      {/* Answer Selection Tips */}
      <Card className="bg-chart-2/10">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Lightbulb className="h-5 w-5 text-chart-2" />
            Evidence-Based Selection Process
          </CardTitle>
        </CardHeader>
        <CardContent>
          <ol className="space-y-3">
            <li className="flex items-start gap-3">
              <div className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-chart-2 text-chart-2-foreground text-sm font-bold">
                1
              </div>
              <div>
                <p className="font-medium mb-1">Read question carefully and identify what it's asking</p>
                <p className="text-sm text-muted-foreground">Note key words like "primarily," "mainly," "most likely," "suggests"</p>
              </div>
            </li>
            <li className="flex items-start gap-3">
              <div className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-chart-2 text-chart-2-foreground text-sm font-bold">
                2
              </div>
              <div>
                <p className="font-medium mb-1">For line reference questions, read 2-3 sentences before and after</p>
                <p className="text-sm text-muted-foreground">Context is crucial—don't rely on referenced lines alone</p>
              </div>
            </li>
            <li className="flex items-start gap-3">
              <div className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-chart-2 text-chart-2-foreground text-sm font-bold">
                3
              </div>
              <div>
                <p className="font-medium mb-1">Predict answer before looking at choices</p>
                <p className="text-sm text-muted-foreground">Then find the choice that best matches your prediction</p>
              </div>
            </li>
            <li className="flex items-start gap-3">
              <div className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-chart-2 text-chart-2-foreground text-sm font-bold">
                4
              </div>
              <div>
                <p className="font-medium mb-1">Eliminate obviously wrong answers first</p>
                <p className="text-sm text-muted-foreground">Cross out extreme, opposite, or irrelevant choices</p>
              </div>
            </li>
            <li className="flex items-start gap-3">
              <div className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-chart-2 text-chart-2-foreground text-sm font-bold">
                5
              </div>
              <div>
                <p className="font-medium mb-1">For remaining choices, find passage evidence</p>
                <p className="text-sm text-muted-foreground">The correct answer MUST be supported by specific text—no assumptions!</p>
              </div>
            </li>
            <li className="flex items-start gap-3">
              <div className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-chart-2 text-chart-2-foreground text-sm font-bold">
                6
              </div>
              <div>
                <p className="font-medium mb-1">If stuck between two answers, reread the question</p>
                <p className="text-sm text-muted-foreground">The question often contains clues about which is better—look for qualifiers like "primarily," "best," "most"</p>
              </div>
            </li>
          </ol>
        </CardContent>
      </Card>
    </div>
  );
}
