import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Clock, Target, Award, AlertCircle, CheckCircle2 } from "lucide-react";

export default function ExamOverviewPage() {
  return (
    <div className="max-w-4xl mx-auto px-6 py-12">
      <div className="mb-8">
        <Badge variant="secondary" className="mb-4">Exam Overview</Badge>
        <h1 className="text-4xl md:text-5xl font-bold mb-4" data-testid="heading-exam-overview">
          AP Language Exam Format
        </h1>
        <p className="text-lg text-muted-foreground leading-relaxed">
          The AP English Language and Composition exam tests your ability to analyze rhetoric and craft compelling arguments. Understanding the format is crucial for success.
        </p>
      </div>

      {/* Exam Structure */}
      <Card className="mb-8">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Clock className="h-5 w-5 text-primary" />
            Exam Structure
          </CardTitle>
          <CardDescription>
            3 hours and 15 minutes total
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div>
            <h3 className="font-semibold text-lg mb-2">Section I: Multiple Choice</h3>
            <ul className="space-y-2 text-muted-foreground">
              <li className="flex items-start gap-2">
                <CheckCircle2 className="h-5 w-5 text-chart-2 shrink-0 mt-0.5" />
                <span><strong>Time:</strong> 1 hour</span>
              </li>
              <li className="flex items-start gap-2">
                <CheckCircle2 className="h-5 w-5 text-chart-2 shrink-0 mt-0.5" />
                <span><strong>Questions:</strong> 45 questions</span>
              </li>
              <li className="flex items-start gap-2">
                <CheckCircle2 className="h-5 w-5 text-chart-2 shrink-0 mt-0.5" />
                <span><strong>Weight:</strong> 45% of exam score</span>
              </li>
              <li className="flex items-start gap-2">
                <CheckCircle2 className="h-5 w-5 text-chart-2 shrink-0 mt-0.5" />
                <span><strong>Format:</strong> 4-5 reading passages with comprehension and analysis questions</span>
              </li>
            </ul>
          </div>

          <Separator />

          <div>
            <h3 className="font-semibold text-lg mb-2">Section II: Free Response</h3>
            <ul className="space-y-2 text-muted-foreground">
              <li className="flex items-start gap-2">
                <CheckCircle2 className="h-5 w-5 text-chart-2 shrink-0 mt-0.5" />
                <span><strong>Time:</strong> 2 hours and 15 minutes (includes 15-minute reading period)</span>
              </li>
              <li className="flex items-start gap-2">
                <CheckCircle2 className="h-5 w-5 text-chart-2 shrink-0 mt-0.5" />
                <span><strong>Essays:</strong> 3 essays</span>
              </li>
              <li className="flex items-start gap-2">
                <CheckCircle2 className="h-5 w-5 text-chart-2 shrink-0 mt-0.5" />
                <span><strong>Weight:</strong> 55% of exam score (approximately 18.3% each)</span>
              </li>
            </ul>
          </div>
        </CardContent>
      </Card>

      {/* Essay Types */}
      <div className="mb-8">
        <h2 className="text-2xl font-bold mb-6 flex items-center gap-2">
          <Target className="h-6 w-6 text-primary" />
          The Three Free Response Questions
        </h2>
        <div className="grid gap-6">
          <Card>
            <CardHeader>
              <CardTitle>Question 1: Synthesis Essay</CardTitle>
              <CardDescription>55 minutes (15-minute reading period + 40 minutes writing)</CardDescription>
            </CardHeader>
            <CardContent className="space-y-3">
              <p className="text-muted-foreground">
                You'll receive 6-7 sources on a topic and must synthesize information from at least 3 sources to develop your own position on the issue.
              </p>
              <div className="bg-muted/50 p-4 rounded-md space-y-2">
                <p className="font-medium text-sm">Key Skills:</p>
                <ul className="text-sm text-muted-foreground space-y-1 ml-4 list-disc">
                  <li>Integrating multiple sources smoothly</li>
                  <li>Developing a clear position</li>
                  <li>Citing sources correctly in parentheses</li>
                  <li>Synthesizing rather than summarizing</li>
                </ul>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Question 2: Rhetorical Analysis Essay</CardTitle>
              <CardDescription>40 minutes</CardDescription>
            </CardHeader>
            <CardContent className="space-y-3">
              <p className="text-muted-foreground">
                Analyze how an author uses rhetorical strategies to achieve their purpose. Focus on the HOW and WHY, not just WHAT the author says.
              </p>
              <div className="bg-muted/50 p-4 rounded-md space-y-2">
                <p className="font-medium text-sm">Key Skills:</p>
                <ul className="text-sm text-muted-foreground space-y-1 ml-4 list-disc">
                  <li>Identifying rhetorical strategies (appeals, devices, tone)</li>
                  <li>Explaining how strategies work</li>
                  <li>Analyzing why strategies are effective</li>
                  <li>Using SPACECAT framework</li>
                </ul>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Question 3: Argument Essay</CardTitle>
              <CardDescription>40 minutes</CardDescription>
            </CardHeader>
            <CardContent className="space-y-3">
              <p className="text-muted-foreground">
                Develop an evidence-based argument responding to a prompt about a contemporary issue. Take a clear position and support it with specific examples.
              </p>
              <div className="bg-muted/50 p-4 rounded-md space-y-2">
                <p className="font-medium text-sm">Key Skills:</p>
                <ul className="text-sm text-muted-foreground space-y-1 ml-4 list-disc">
                  <li>Taking a clear, defensible position</li>
                  <li>Using specific, relevant evidence</li>
                  <li>Addressing counterarguments</li>
                  <li>Demonstrating line of reasoning</li>
                </ul>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Scoring */}
      <Card className="mb-8">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Award className="h-5 w-5 text-primary" />
            Scoring System
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <p className="text-muted-foreground">
            Essays are scored on a 0-6 scale by AP readers. The multiple choice section is scored by computer. These scores are combined and converted to the final AP score of 1-5.
          </p>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <h4 className="font-semibold">AP Score Meanings</h4>
              <ul className="space-y-2 text-sm">
                <li className="flex items-start gap-2">
                  <Badge variant="default" className="shrink-0">5</Badge>
                  <span className="text-muted-foreground">Extremely well qualified (eligible for college credit)</span>
                </li>
                <li className="flex items-start gap-2">
                  <Badge variant="secondary" className="shrink-0">4</Badge>
                  <span className="text-muted-foreground">Well qualified (often eligible for credit)</span>
                </li>
                <li className="flex items-start gap-2">
                  <Badge variant="secondary" className="shrink-0">3</Badge>
                  <span className="text-muted-foreground">Qualified (sometimes eligible for credit)</span>
                </li>
                <li className="flex items-start gap-2">
                  <Badge variant="outline" className="shrink-0">2</Badge>
                  <span className="text-muted-foreground">Possibly qualified</span>
                </li>
                <li className="flex items-start gap-2">
                  <Badge variant="outline" className="shrink-0">1</Badge>
                  <span className="text-muted-foreground">No recommendation</span>
                </li>
              </ul>
            </div>
            
            <div className="bg-muted/50 p-4 rounded-md">
              <h4 className="font-semibold mb-3 text-sm">Typical Score Distribution</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li>Score 5: ~10-15% of students</li>
                <li>Score 4: ~17-20% of students</li>
                <li>Score 3: ~25-30% of students</li>
                <li>Score 2: ~20-25% of students</li>
                <li>Score 1: ~10-15% of students</li>
              </ul>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Test Day Tips */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <AlertCircle className="h-5 w-5 text-chart-4" />
            Test Day Timeline
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-4">
            <div className="border-l-4 border-l-primary pl-4">
              <h4 className="font-semibold mb-1">Section I: Multiple Choice</h4>
              <p className="text-sm text-muted-foreground">1 hour - 45 questions on 4-5 passages</p>
            </div>
            <div className="border-l-4 border-l-primary pl-4">
              <h4 className="font-semibold mb-1">10-Minute Break</h4>
              <p className="text-sm text-muted-foreground">Rest and prepare for free response</p>
            </div>
            <div className="border-l-4 border-l-chart-2 pl-4">
              <h4 className="font-semibold mb-1">Section II: Free Response Questions</h4>
              <p className="text-sm text-muted-foreground mb-2">2 hours 15 minutes total</p>
              <ul className="text-sm text-muted-foreground space-y-1 ml-4 list-disc">
                <li>15-minute reading period (for Synthesis sources)</li>
                <li>40 minutes: Synthesis Essay</li>
                <li>40 minutes: Rhetorical Analysis Essay</li>
                <li>40 minutes: Argument Essay</li>
              </ul>
            </div>
          </div>

          <div className="bg-chart-4/10 text-chart-4 p-4 rounded-md">
            <p className="font-medium text-sm mb-2">Pro Tip:</p>
            <p className="text-sm">
              During the 15-minute reading period, you can ONLY work on the Synthesis essay sources. Use this time to annotate, code sources (A, B, C, etc.), and plan your synthesis essay. You cannot start writing during this period.
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
