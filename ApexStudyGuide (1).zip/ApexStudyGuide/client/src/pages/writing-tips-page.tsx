import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Lightbulb, Zap, ArrowRight, AlertTriangle } from "lucide-react";
import { writingTips } from "@/data/writingTips";

export default function WritingTipsPage() {
  const categories = [
    { id: "sophistication", label: "Sophistication", icon: Zap, description: "Elevate your writing with nuanced thinking" },
    { id: "syntax", label: "Syntax Variety", icon: ArrowRight, description: "Create engaging rhythm and flow" },
    { id: "transitions", label: "Transitions", icon: ArrowRight, description: "Connect ideas smoothly" },
    { id: "pitfalls", label: "Common Pitfalls", icon: AlertTriangle, description: "Avoid mistakes that cost points" }
  ];

  return (
    <div className="max-w-5xl mx-auto px-6 py-12">
      <div className="mb-8">
        <Badge variant="secondary" className="mb-4">Writing Tips</Badge>
        <h1 className="text-4xl md:text-5xl font-bold mb-4 flex items-center gap-3" data-testid="heading-writing-tips">
          <Lightbulb className="h-10 w-10 text-primary" />
          Writing Excellence Guide
        </h1>
        <p className="text-lg text-muted-foreground leading-relaxed max-w-3xl">
          Master sophistication strategies, syntax variety, smooth transitions, and avoid common pitfalls that cost points on AP Lang essays.
        </p>
      </div>

      <Tabs defaultValue="sophistication" className="space-y-8">
        <TabsList className="grid w-full grid-cols-2 md:grid-cols-4">
          {categories.map(category => {
            const Icon = category.icon;
            return (
              <TabsTrigger key={category.id} value={category.id} data-testid={`tab-${category.id}`}>
                <Icon className="h-4 w-4 mr-2" />
                {category.label}
              </TabsTrigger>
            );
          })}
        </TabsList>

        {categories.map(category => {
          const Icon = category.icon;
          const categoryTips = writingTips.filter(tip => tip.category === category.id);
          
          return (
            <TabsContent key={category.id} value={category.id} className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2 text-2xl">
                    <Icon className="h-6 w-6 text-primary" />
                    {category.label}
                  </CardTitle>
                  <CardDescription className="text-base">
                    {category.description}
                  </CardDescription>
                </CardHeader>
              </Card>

              <div className="grid gap-6">
                {categoryTips.map((tip) => (
                  <Card key={tip.id} className="hover-elevate" data-testid={`card-tip-${tip.id}`}>
                    <CardHeader>
                      <CardTitle className="text-xl">{tip.title}</CardTitle>
                      <CardDescription className="text-base leading-relaxed">
                        {tip.description}
                      </CardDescription>
                    </CardHeader>
                    {tip.examples && tip.examples.length > 0 && (
                      <CardContent>
                        <div className="bg-muted/50 p-4 rounded-md space-y-3">
                          <h4 className="font-semibold text-sm">Examples:</h4>
                          {tip.examples.map((example, index) => (
                            <div key={index} className="space-y-1">
                              {example.includes('Instead of:') || example.includes('Write:') || example.includes('Don\'t:') || example.includes('Do:') || example.includes('Weak:') || example.includes('Strong:') || example.includes('Better:') || example.includes('Best:') || example.includes('Wrong:') || example.includes('Right:') || example.includes('Avoid:') || example.includes('Obvious:') || example.includes('Analytical:') ? (
                                <p className="text-sm font-mono leading-relaxed">
                                  {example}
                                </p>
                              ) : (
                                <div className="flex items-start gap-2">
                                  <div className="h-2 w-2 rounded-full bg-primary shrink-0 mt-2" />
                                  <p className="text-sm font-mono leading-relaxed">
                                    {example}
                                  </p>
                                </div>
                              )}
                            </div>
                          ))}
                        </div>
                      </CardContent>
                    )}
                  </Card>
                ))}
              </div>
            </TabsContent>
          );
        })}
      </Tabs>
    </div>
  );
}
