import { useState, useMemo } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { ScrollArea } from "@/components/ui/scroll-area";
import { FileText, Search, MessageSquare, Link as LinkIcon, Eye } from "lucide-react";
import { practicePrompts } from "@/data/practicePrompts";
import { PracticePrompt } from "@shared/schema";

export default function PracticePromptsPage() {
  const [activeType, setActiveType] = useState<string>("all");

  const promptTypes = [
    { id: "all", label: "All Prompts", icon: FileText, count: practicePrompts.length },
    { id: "rhetorical-analysis", label: "Rhetorical Analysis", icon: Search, count: practicePrompts.filter(p => p.type === "rhetorical-analysis").length },
    { id: "argument", label: "Argument", icon: MessageSquare, count: practicePrompts.filter(p => p.type === "argument").length },
    { id: "synthesis", label: "Synthesis", icon: LinkIcon, count: practicePrompts.filter(p => p.type === "synthesis").length }
  ];

  const filteredPrompts = useMemo(() => {
    if (activeType === "all") return practicePrompts;
    return practicePrompts.filter(prompt => prompt.type === activeType);
  }, [activeType]);

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case "easy": return "bg-chart-2/10 text-chart-2";
      case "medium": return "bg-chart-4/10 text-chart-4";
      case "hard": return "bg-destructive/10 text-destructive";
      default: return "bg-muted text-muted-foreground";
    }
  };

  const getTypeColor = (type: string) => {
    switch (type) {
      case "rhetorical-analysis": return "bg-primary/10 text-primary";
      case "argument": return "bg-chart-3/10 text-chart-3";
      case "synthesis": return "bg-chart-4/10 text-chart-4";
      default: return "bg-muted text-muted-foreground";
    }
  };

  return (
    <div className="max-w-6xl mx-auto px-6 py-12">
      <div className="mb-8">
        <Badge variant="secondary" className="mb-4">Practice Prompts</Badge>
        <h1 className="text-4xl md:text-5xl font-bold mb-4" data-testid="heading-practice-prompts">
          AP Lang Practice Prompts
        </h1>
        <p className="text-lg text-muted-foreground leading-relaxed max-w-3xl">
          Practice with 20+ real AP-style prompts across all three essay types. Each prompt includes sample responses and scoring guidance.
        </p>
      </div>

      {/* Type Tabs */}
      <Tabs value={activeType} onValueChange={setActiveType} className="mb-8">
        <TabsList className="flex flex-wrap h-auto gap-2 bg-transparent justify-start">
          {promptTypes.map(type => {
            const Icon = type.icon;
            return (
              <TabsTrigger 
                key={type.id} 
                value={type.id}
                className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground"
                data-testid={`tab-type-${type.id}`}
              >
                <Icon className="h-4 w-4 mr-2" />
                {type.label}
                <Badge variant="secondary" className="ml-2 text-xs">
                  {type.count}
                </Badge>
              </TabsTrigger>
            );
          })}
        </TabsList>
      </Tabs>

      {/* Results Count */}
      <div className="mb-6">
        <p className="text-sm text-muted-foreground" data-testid="text-prompts-count">
          Showing {filteredPrompts.length} {filteredPrompts.length === 1 ? 'prompt' : 'prompts'}
        </p>
      </div>

      {/* Prompts Grid */}
      <div className="grid grid-cols-1 gap-6">
        {filteredPrompts.map((prompt) => (
          <PromptCard key={prompt.id} prompt={prompt} getDifficultyColor={getDifficultyColor} getTypeColor={getTypeColor} />
        ))}
      </div>
    </div>
  );
}

function PromptCard({ prompt, getDifficultyColor, getTypeColor }: { 
  prompt: PracticePrompt, 
  getDifficultyColor: (d: string) => string,
  getTypeColor: (t: string) => string 
}) {
  return (
    <Card className="hover-elevate" data-testid={`card-prompt-${prompt.id}`}>
      <CardHeader>
        <div className="flex flex-wrap items-start justify-between gap-4 mb-2">
          <div className="flex-1">
            <CardTitle className="text-xl mb-2">{prompt.title}</CardTitle>
            <CardDescription className="text-base">
              {prompt.type.split('-').map(word => word.charAt(0).toUpperCase() + word.slice(1)).join(' ')} Essay
            </CardDescription>
          </div>
          <div className="flex flex-wrap gap-2">
            <Badge className={getDifficultyColor(prompt.difficulty)}>
              {prompt.difficulty.charAt(0).toUpperCase() + prompt.difficulty.slice(1)}
            </Badge>
            <Badge className={getTypeColor(prompt.type)} variant="outline">
              {prompt.type.split('-').join(' ')}
            </Badge>
          </div>
        </div>
        
        {prompt.theme.length > 0 && (
          <div className="flex flex-wrap gap-2 mt-2">
            {prompt.theme.map((theme) => (
              <Badge key={theme} variant="secondary" className="text-xs">
                {theme}
              </Badge>
            ))}
          </div>
        )}
      </CardHeader>
      <CardContent className="space-y-4">
        <div>
          <h4 className="font-semibold text-sm mb-2">Prompt:</h4>
          <p className="text-sm text-muted-foreground leading-relaxed line-clamp-4">
            {prompt.prompt}
          </p>
        </div>
        
        <div className="flex flex-wrap gap-3">
          <Dialog>
            <DialogTrigger asChild>
              <Button variant="default" size="sm" data-testid={`button-view-prompt-${prompt.id}`}>
                <Eye className="h-4 w-4 mr-2" />
                View Full Prompt
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-3xl max-h-[80vh]">
              <DialogHeader>
                <DialogTitle>{prompt.title}</DialogTitle>
                <DialogDescription>
                  {prompt.type.split('-').map(word => word.charAt(0).toUpperCase() + word.slice(1)).join(' ')} Essay • {prompt.difficulty.charAt(0).toUpperCase() + prompt.difficulty.slice(1)} Difficulty
                </DialogDescription>
              </DialogHeader>
              <ScrollArea className="max-h-[60vh] pr-4">
                <div className="space-y-6">
                  <div>
                    <h4 className="font-semibold mb-3">Prompt:</h4>
                    <p className="text-sm leading-relaxed text-muted-foreground">
                      {prompt.prompt}
                    </p>
                  </div>
                  
                  {prompt.sampleResponse && (
                    <div className="bg-muted/50 p-4 rounded-md">
                      <h4 className="font-semibold mb-3">Sample Response Opening:</h4>
                      <p className="text-sm leading-relaxed italic">
                        {prompt.sampleResponse}
                      </p>
                    </div>
                  )}
                  
                  {prompt.rubric && (
                    <div>
                      <h4 className="font-semibold mb-3">Scoring Focus:</h4>
                      <p className="text-sm leading-relaxed text-muted-foreground">
                        {prompt.rubric}
                      </p>
                    </div>
                  )}
                  
                  <div className="bg-chart-4/10 text-chart-4 p-4 rounded-md">
                    <p className="font-medium text-sm mb-2">Practice Tips:</p>
                    <ul className="text-sm space-y-1 ml-4 list-disc">
                      <li>Time yourself: 40 minutes for Rhetorical Analysis and Argument, 55 minutes for Synthesis (including 15-minute reading period)</li>
                      <li>Spend 8-10 minutes planning before you start writing</li>
                      <li>Focus on analysis and commentary, not just summary</li>
                      <li>Save 3-5 minutes to proofread your essay</li>
                    </ul>
                  </div>
                </div>
              </ScrollArea>
            </DialogContent>
          </Dialog>
        </div>
      </CardContent>
    </Card>
  );
}
