import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { BookOpen, Search, MessageSquare, Link as LinkIcon, CheckSquare, Sparkles, Lightbulb, FileText, Calendar, Download, ArrowRight, Clock, Target, TrendingUp } from "lucide-react";
import heroImage from "@assets/generated_images/AP_Lang_study_materials_hero_26cb18eb.png";

export default function HomePage() {
  const features = [
    {
      icon: Target,
      title: "Comprehensive Strategies",
      description: "Master every essay type with proven frameworks, formulas, and step-by-step guides",
      color: "text-primary"
    },
    {
      icon: FileText,
      title: "Real AP-Style Prompts",
      description: "Practice with 20+ authentic prompts complete with sample responses and rubrics",
      color: "text-chart-2"
    },
    {
      icon: TrendingUp,
      title: "Score Higher",
      description: "Learn sophistication techniques and avoid common pitfalls that cost points",
      color: "text-chart-4"
    }
  ];

  const examSections = [
    {
      icon: CheckSquare,
      title: "Multiple Choice",
      description: "45 Questions",
      time: "1 Hour",
      weight: "45%",
      path: "/mcq/strategies",
      color: "bg-primary/10 text-primary"
    },
    {
      icon: Search,
      title: "Rhetorical Analysis",
      description: "Analyze author's strategies",
      time: "40 Minutes",
      weight: "~18%",
      path: "/rhetorical-analysis/overview",
      color: "bg-chart-2/10 text-chart-2"
    },
    {
      icon: MessageSquare,
      title: "Argument Essay",
      description: "Defend a position",
      time: "40 Minutes",
      weight: "~18%",
      path: "/argument/overview",
      color: "bg-chart-3/10 text-chart-3"
    },
    {
      icon: LinkIcon,
      title: "Synthesis Essay",
      description: "Integrate multiple sources",
      time: "55 Minutes (15 min reading)",
      weight: "~18%",
      path: "/synthesis/overview",
      color: "bg-chart-4/10 text-chart-4"
    }
  ];

  const quickStartSteps = [
    {
      number: "1",
      title: "Understand the Exam",
      description: "Review the exam format, timing, and scoring system",
      link: "/overview/format"
    },
    {
      number: "2",
      title: "Learn the Frameworks",
      description: "Master SPACECAT, thesis formulas, and essay structures",
      link: "/rhetorical-analysis/spacecat"
    },
    {
      number: "3",
      title: "Study Rhetorical Devices",
      description: "Build your vocabulary of 50+ rhetorical terms and strategies",
      link: "/devices/all"
    },
    {
      number: "4",
      title: "Practice with Prompts",
      description: "Write essays using real AP-style prompts and compare to samples",
      link: "/practice/all"
    },
    {
      number: "5",
      title: "Follow a Study Plan",
      description: "Use our structured schedules for consistent preparation",
      link: "/study/3-month"
    }
  ];

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative min-h-[70vh] flex items-center justify-center overflow-hidden">
        {/* Background Image with Dark Overlay */}
        <div className="absolute inset-0 z-0">
          <img
            src={heroImage}
            alt="AP Language study materials"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-br from-background/95 via-background/90 to-background/85" />
        </div>

        {/* Hero Content */}
        <div className="relative z-10 max-w-5xl mx-auto px-6 py-24 text-center">
          <Badge variant="secondary" className="mb-6 text-sm font-medium" data-testid="badge-hero">
            The Complete AP Lang Exam Guide
          </Badge>
          <h1 className="text-5xl md:text-6xl lg:text-7xl font-bold mb-6 leading-tight" data-testid="heading-hero-title">
            Master the AP Language Exam
          </h1>
          <p className="text-xl md:text-2xl text-muted-foreground mb-10 max-w-3xl mx-auto leading-relaxed" data-testid="text-hero-subtitle">
            Everything you need to ace rhetorical analysis, argument essays, synthesis writing, and multiple choice questions. Expert strategies, practice prompts, and comprehensive study guides all in one place.
          </p>
          <div className="flex flex-wrap items-center justify-center gap-4">
            <Link href="/overview/format">
              <Button size="lg" className="text-base px-8" data-testid="button-start-learning">
                Start Learning
                <ArrowRight className="ml-2 h-5 w-5" />
              </Button>
            </Link>
            <Link href="/devices/all">
              <Button size="lg" variant="outline" className="text-base px-8" data-testid="button-browse-topics">
                Browse Topics
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Features Grid */}
      <section className="py-16 md:py-24 bg-muted/30">
        <div className="max-w-7xl mx-auto px-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {features.map((feature) => (
              <Card key={feature.title} className="hover-elevate" data-testid={`card-feature-${feature.title.toLowerCase().replace(/\s+/g, '-')}`}>
                <CardHeader>
                  <feature.icon className={`h-10 w-10 mb-4 ${feature.color}`} />
                  <CardTitle className="text-xl">{feature.title}</CardTitle>
                  <CardDescription className="text-base leading-relaxed">
                    {feature.description}
                  </CardDescription>
                </CardHeader>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Exam Breakdown */}
      <section className="py-16 md:py-24">
        <div className="max-w-7xl mx-auto px-6">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4" data-testid="heading-exam-breakdown">
              Exam Breakdown
            </h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto" data-testid="text-exam-breakdown-description">
              The AP Language exam consists of four sections testing your ability to analyze rhetoric and craft compelling arguments
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {examSections.map((section) => (
              <Link key={section.title} href={section.path}>
                <Card className="h-full hover-elevate cursor-pointer" data-testid={`card-exam-section-${section.title.toLowerCase().replace(/\s+/g, '-')}`}>
                  <CardHeader className="space-y-4">
                    <div className={`w-12 h-12 rounded-md ${section.color} flex items-center justify-center`}>
                      <section.icon className="h-6 w-6" />
                    </div>
                    <CardTitle className="text-lg">{section.title}</CardTitle>
                    <CardDescription className="text-sm">
                      {section.description}
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-2">
                    <div className="flex items-center gap-2 text-sm">
                      <Clock className="h-4 w-4 text-muted-foreground" />
                      <span>{section.time}</span>
                    </div>
                    <div className="flex items-center gap-2 text-sm font-medium">
                      <Target className="h-4 w-4 text-muted-foreground" />
                      <span>{section.weight} of score</span>
                    </div>
                  </CardContent>
                </Card>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* Quick Start Guide */}
      <section className="py-16 md:py-24 bg-muted/30">
        <div className="max-w-5xl mx-auto px-6">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4" data-testid="heading-quick-start">
              Quick Start Guide
            </h2>
            <p className="text-lg text-muted-foreground" data-testid="text-quick-start-description">
              Follow these steps to maximize your AP Lang preparation
            </p>
          </div>
          <div className="space-y-6">
            {quickStartSteps.map((step) => (
              <Link key={step.number} href={step.link}>
                <Card className="hover-elevate cursor-pointer" data-testid={`card-step-${step.number}`}>
                  <CardHeader className="flex flex-row items-start gap-4 space-y-0">
                    <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-md bg-primary text-primary-foreground text-lg font-bold">
                      {step.number}
                    </div>
                    <div className="flex-1">
                      <CardTitle className="text-xl mb-2">{step.title}</CardTitle>
                      <CardDescription className="text-base">
                        {step.description}
                      </CardDescription>
                    </div>
                    <ArrowRight className="h-5 w-5 text-muted-foreground shrink-0" />
                  </CardHeader>
                </Card>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* Featured Resources */}
      <section className="py-16 md:py-24">
        <div className="max-w-7xl mx-auto px-6">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4" data-testid="heading-featured-resources">
              Featured Resources
            </h2>
            <p className="text-lg text-muted-foreground" data-testid="text-featured-resources-description">
              Essential tools and guides for exam success
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <Link href="/devices/all">
              <Card className="hover-elevate cursor-pointer h-full" data-testid="card-resource-devices">
                <CardHeader>
                  <Sparkles className="h-8 w-8 mb-3 text-chart-3" />
                  <CardTitle>Rhetorical Devices Library</CardTitle>
                  <CardDescription className="text-base">
                    50+ devices with definitions, effects, and AP exam examples
                  </CardDescription>
                </CardHeader>
              </Card>
            </Link>
            <Link href="/practice/all">
              <Card className="hover-elevate cursor-pointer h-full" data-testid="card-resource-prompts">
                <CardHeader>
                  <FileText className="h-8 w-8 mb-3 text-chart-2" />
                  <CardTitle>Practice Prompts</CardTitle>
                  <CardDescription className="text-base">
                    20+ real AP-style prompts with sample responses and rubrics
                  </CardDescription>
                </CardHeader>
              </Card>
            </Link>
            <Link href="/resources/cheat-sheets">
              <Card className="hover-elevate cursor-pointer h-full" data-testid="card-resource-cheat-sheets">
                <CardHeader>
                  <Download className="h-8 w-8 mb-3 text-chart-4" />
                  <CardTitle>Quick Reference Sheets</CardTitle>
                  <CardDescription className="text-base">
                    Downloadable cheat sheets for formulas, tone words, and essay structures
                  </CardDescription>
                </CardHeader>
              </Card>
            </Link>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 md:py-24 bg-primary text-primary-foreground">
        <div className="max-w-4xl mx-auto px-6 text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-4" data-testid="heading-cta">
            Ready to Excel on the AP Lang Exam?
          </h2>
          <p className="text-lg mb-8 opacity-90" data-testid="text-cta-description">
            This comprehensive guide is open source and designed to help every AP Lang student succeed. Start exploring the strategies and practice materials now.
          </p>
          <div className="flex flex-wrap items-center justify-center gap-4">
            <Link href="/overview/format">
              <Button size="lg" variant="secondary" className="text-base px-8" data-testid="button-get-started">
                Get Started
                <ArrowRight className="ml-2 h-5 w-5" />
              </Button>
            </Link>
            <Button
              size="lg"
              variant="outline"
              className="text-base px-8 bg-transparent border-primary-foreground text-primary-foreground hover-elevate"
              asChild
              data-testid="button-view-github"
            >
              <a href="https://github.com" target="_blank" rel="noopener noreferrer">
                View on GitHub
              </a>
            </Button>
          </div>
        </div>
      </section>
    </div>
  );
}
