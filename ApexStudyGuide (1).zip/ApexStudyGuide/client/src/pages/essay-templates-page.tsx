import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { Clock, Lightbulb, FileText } from "lucide-react";
import { essayTemplates } from "@/data/essayTemplates";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

export default function EssayTemplatesPage() {
  return (
    <div className="max-w-5xl mx-auto px-6 py-12">
      <div className="mb-8">
        <Badge variant="secondary" className="mb-4">Essay Templates</Badge>
        <h1 className="text-4xl md:text-5xl font-bold mb-4" data-testid="heading-essay-templates">
          Essay Structure Templates
        </h1>
        <p className="text-lg text-muted-foreground leading-relaxed max-w-3xl">
          Step-by-step templates for all three FRQ types with timing strategies, formulas, and paragraph-by-paragraph guides.
        </p>
      </div>

      <Tabs defaultValue="rhetorical-analysis" className="space-y-8">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="rhetorical-analysis" data-testid="tab-ra-template">
            Rhetorical Analysis
          </TabsTrigger>
          <TabsTrigger value="argument" data-testid="tab-arg-template">
            Argument
          </TabsTrigger>
          <TabsTrigger value="synthesis" data-testid="tab-syn-template">
            Synthesis
          </TabsTrigger>
        </TabsList>

        {essayTemplates.map((template) => (
          <TabsContent key={template.id} value={template.type} className="space-y-6">
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between gap-4">
                  <div>
                    <CardTitle className="text-2xl mb-2">{template.title}</CardTitle>
                    <CardDescription className="text-base flex items-center gap-2">
                      <Clock className="h-4 w-4" />
                      {template.timeAllocation}
                    </CardDescription>
                  </div>
                  <FileText className="h-10 w-10 text-primary shrink-0" />
                </div>
              </CardHeader>
            </Card>

            {/* Structure Accordion */}
            <Card>
              <CardHeader>
                <CardTitle>Step-by-Step Structure</CardTitle>
                <CardDescription>
                  Follow this proven template for maximum points
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Accordion type="single" collapsible className="w-full">
                  {template.structure.map((section, index) => (
                    <AccordionItem key={index} value={`section-${index}`}>
                      <AccordionTrigger className="hover:no-underline" data-testid={`accordion-section-${index}`}>
                        <div className="flex items-center justify-between w-full pr-4">
                          <span className="font-semibold text-base">{section.section}</span>
                          <Badge variant="outline" className="ml-4">
                            {section.timeMinutes} min
                          </Badge>
                        </div>
                      </AccordionTrigger>
                      <AccordionContent>
                        <div className="pt-4 pb-2 space-y-3">
                          {section.content.map((item, itemIndex) => (
                            <div key={itemIndex} className="flex items-start gap-3 text-sm">
                              <div className="h-2 w-2 rounded-full bg-primary shrink-0 mt-2" />
                              <p className="text-muted-foreground leading-relaxed">{item}</p>
                            </div>
                          ))}
                        </div>
                      </AccordionContent>
                    </AccordionItem>
                  ))}
                </Accordion>
              </CardContent>
            </Card>

            {/* Tips */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Lightbulb className="h-5 w-5 text-chart-4" />
                  Essential Tips
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="space-y-3">
                  {template.tips.map((tip, index) => (
                    <li key={index} className="flex items-start gap-3">
                      <div className="h-2 w-2 rounded-full bg-chart-4 shrink-0 mt-2" />
                      <p className="text-sm text-muted-foreground leading-relaxed">{tip}</p>
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>

            {/* Time Management Visual */}
            <Card className="bg-muted/30">
              <CardHeader>
                <CardTitle className="text-lg">Time Allocation Breakdown</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {template.structure.map((section, index) => {
                    const totalTime = template.structure.reduce((acc, s) => acc + s.timeMinutes, 0);
                    const percentage = (section.timeMinutes / totalTime) * 100;
                    
                    return (
                      <div key={index} className="space-y-1">
                        <div className="flex items-center justify-between text-sm">
                          <span className="font-medium">{section.section}</span>
                          <span className="text-muted-foreground">{section.timeMinutes} min ({percentage.toFixed(0)}%)</span>
                        </div>
                        <div className="h-2 bg-muted rounded-full overflow-hidden">
                          <div 
                            className="h-full bg-primary rounded-full transition-all"
                            style={{ width: `${percentage}%` }}
                          />
                        </div>
                      </div>
                    );
                  })}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        ))}
      </Tabs>
    </div>
  );
}
