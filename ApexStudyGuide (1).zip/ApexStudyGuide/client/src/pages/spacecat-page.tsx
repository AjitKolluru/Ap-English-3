import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { User, Target, Users, Calendar, Zap, Pencil, MessageCircle, Smile } from "lucide-react";

export default function SpacecatPage() {
  const spacecatElements = [
    {
      letter: "S",
      term: "Speaker",
      icon: User,
      description: "Who is the author/speaker? What is their background, credentials, or perspective?",
      questions: [
        "Who wrote or delivered this text?",
        "What is their background or expertise?",
        "What biases or perspectives might they have?",
        "How does their identity/position affect their credibility?"
      ],
      example: "Martin Luther King Jr., a Baptist minister and civil rights leader, brings moral authority and lived experience to his 'Letter from Birmingham Jail.'"
    },
    {
      letter: "P",
      term: "Purpose",
      icon: Target,
      description: "What is the author trying to achieve? What do they want the audience to think, feel, or do?",
      questions: [
        "What is the main goal of this text?",
        "What does the author want the audience to believe or do?",
        "Is the purpose to inform, persuade, entertain, or inspire?",
        "Are there multiple layers of purpose?"
      ],
      example: "King's purpose is to defend his presence in Birmingham, justify civil disobedience, and persuade moderate clergy to support the civil rights movement."
    },
    {
      letter: "A",
      term: "Audience",
      icon: Users,
      description: "Who is the intended audience? What are their values, beliefs, and concerns?",
      questions: [
        "Who is the primary intended audience?",
        "What values or beliefs does this audience hold?",
        "What knowledge does the audience already have?",
        "How might the audience initially view this topic?"
      ],
      example: "King addresses white moderate clergy who sympathize with civil rights goals but criticize his methods as too extreme or untimely."
    },
    {
      letter: "C",
      term: "Context",
      icon: Calendar,
      description: "When and where was this written? What historical, cultural, or social factors are relevant?",
      questions: [
        "When and where was this created?",
        "What historical events are relevant?",
        "What was happening culturally or politically?",
        "What conversations was this text joining?"
      ],
      example: "Written in 1963 during the height of the civil rights movement, after King's arrest for nonviolent protests against segregation in Birmingham, Alabama."
    },
    {
      letter: "E",
      term: "Exigence",
      icon: Zap,
      description: "What prompted the author to write this now? What problem or situation demands a response?",
      questions: [
        "What issue or problem sparked this text?",
        "Why did the author feel compelled to write this now?",
        "What recent event triggered this response?",
        "What makes this moment significant?"
      ],
      example: "Eight white clergymen published a statement calling King's protests 'unwise and untimely,' prompting his detailed written response defending his actions."
    },
    {
      letter: "C",
      term: "Choices",
      icon: Pencil,
      description: "What rhetorical strategies, devices, and techniques does the author use?",
      questions: [
        "What rhetorical appeals do they use (ethos, pathos, logos)?",
        "What specific devices appear (metaphor, parallelism, anaphora)?",
        "How is the text organized or structured?",
        "What diction, syntax, or imagery stands out?"
      ],
      example: "King employs biblical allusions, parallel structure, emotional appeals, logical reasoning, and direct address to create a compelling multi-layered argument."
    },
    {
      letter: "A",
      term: "Appeals",
      icon: MessageCircle,
      description: "How does the author establish credibility (ethos), evoke emotions (pathos), and use logic (logos)?",
      questions: [
        "How does the author establish credibility (ethos)?",
        "What emotions does the text evoke (pathos)?",
        "What logical arguments or evidence appear (logos)?",
        "Which appeal dominates, and why?"
      ],
      example: "King establishes ethos through religious authority, evokes pathos describing children's questions about segregation, and uses logos citing legal and moral philosophy."
    },
    {
      letter: "T",
      term: "Tone",
      icon: Smile,
      description: "What is the author's attitude toward the subject and audience? How does tone shift?",
      questions: [
        "What is the overall tone (formal, passionate, somber, optimistic)?",
        "Does the tone shift? Where and why?",
        "How does word choice create tone?",
        "How does tone affect the audience's response?"
      ],
      example: "King's tone shifts from respectful and measured when addressing the clergy, to passionate and urgent when discussing injustice, to hopeful when envisioning change."
    }
  ];

  return (
    <div className="max-w-5xl mx-auto px-6 py-12">
      <div className="mb-8">
        <Badge variant="secondary" className="mb-4">Rhetorical Analysis Framework</Badge>
        <h1 className="text-4xl md:text-5xl font-bold mb-4" data-testid="heading-spacecat">
          SPACECAT Framework
        </h1>
        <p className="text-lg text-muted-foreground leading-relaxed max-w-3xl">
          Master rhetorical analysis with SPACECAT—a comprehensive framework for analyzing any text. This systematic approach ensures you consider all essential elements of rhetoric.
        </p>
      </div>

      {/* Overview Card */}
      <Card className="mb-8 bg-primary/5">
        <CardHeader>
          <CardTitle className="text-2xl">What is SPACECAT?</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <p className="text-muted-foreground leading-relaxed">
            SPACECAT is an acronym that helps you systematically analyze rhetorical texts by considering eight key elements. Use this framework when reading passages for the Rhetorical Analysis essay to ensure comprehensive analysis.
          </p>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {spacecatElements.map((element) => (
              <div key={element.letter} className="text-center">
                <div className="inline-flex h-12 w-12 items-center justify-center rounded-md bg-primary text-primary-foreground text-xl font-bold mb-2">
                  {element.letter}
                </div>
                <p className="text-sm font-medium">{element.term}</p>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Detailed Elements */}
      <div className="space-y-6">
        {spacecatElements.map((element, index) => {
          const Icon = element.icon;
          return (
            <Card key={element.term} className="hover-elevate" data-testid={`card-spacecat-${element.term.toLowerCase()}`}>
              <CardHeader>
                <div className="flex items-start gap-4">
                  <div className="flex h-14 w-14 shrink-0 items-center justify-center rounded-md bg-primary text-primary-foreground text-2xl font-bold">
                    {element.letter}
                  </div>
                  <div className="flex-1">
                    <CardTitle className="text-2xl mb-2 flex items-center gap-2">
                      {element.term}
                      <Icon className="h-5 w-5 text-muted-foreground" />
                    </CardTitle>
                    <CardDescription className="text-base leading-relaxed">
                      {element.description}
                    </CardDescription>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <h4 className="font-semibold text-sm mb-3">Questions to Ask:</h4>
                  <ul className="space-y-2">
                    {element.questions.map((question, qIndex) => (
                      <li key={qIndex} className="flex items-start gap-2 text-sm text-muted-foreground">
                        <div className="h-1.5 w-1.5 rounded-full bg-primary shrink-0 mt-2" />
                        <span>{question}</span>
                      </li>
                    ))}
                  </ul>
                </div>
                
                <div className="bg-muted/50 p-4 rounded-md">
                  <h4 className="font-semibold text-sm mb-2">Example (MLK's Letter from Birmingham Jail):</h4>
                  <p className="text-sm italic leading-relaxed">
                    {element.example}
                  </p>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* How to Use */}
      <Card className="mt-8 bg-chart-4/10">
        <CardHeader>
          <CardTitle>How to Use SPACECAT in Your Essay</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <h4 className="font-semibold mb-2">During Reading (10 minutes):</h4>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li className="flex items-start gap-2">
                <div className="h-2 w-2 rounded-full bg-chart-4 shrink-0 mt-2" />
                <span>Quickly identify S, P, A, C, E while reading the passage and prompt</span>
              </li>
              <li className="flex items-start gap-2">
                <div className="h-2 w-2 rounded-full bg-chart-4 shrink-0 mt-2" />
                <span>Annotate the second C (Choices) - circle rhetorical devices and strategies</span>
              </li>
              <li className="flex items-start gap-2">
                <div className="h-2 w-2 rounded-full bg-chart-4 shrink-0 mt-2" />
                <span>Note A (Appeals) and T (Tone) in the margins</span>
              </li>
            </ul>
          </div>

          <div>
            <h4 className="font-semibold mb-2">In Your Essay:</h4>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li className="flex items-start gap-2">
                <div className="h-2 w-2 rounded-full bg-chart-4 shrink-0 mt-2" />
                <span><strong>Introduction:</strong> Briefly establish S, P, A, C, E to show you understand the rhetorical situation</span>
              </li>
              <li className="flex items-start gap-2">
                <div className="h-2 w-2 rounded-full bg-chart-4 shrink-0 mt-2" />
                <span><strong>Body Paragraphs:</strong> Focus on C (Choices), A (Appeals), and T (Tone) - analyze specific strategies</span>
              </li>
              <li className="flex items-start gap-2">
                <div className="h-2 w-2 rounded-full bg-chart-4 shrink-0 mt-2" />
                <span><strong>Analysis:</strong> Always connect choices back to purpose and audience - explain WHY strategies are effective</span>
              </li>
            </ul>
          </div>

          <div className="bg-background p-4 rounded-md border border-chart-4">
            <p className="font-medium text-sm mb-2 text-chart-4">Pro Tip:</p>
            <p className="text-sm">
              Don't mechanically list all SPACECAT elements. Use the framework as a thinking tool during reading, then focus your essay on the most significant rhetorical choices (C, A, T) and how they achieve the author's purpose.
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
