import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { SidebarProvider, SidebarTrigger } from "@/components/ui/sidebar";
import { AppSidebar } from "@/components/app-sidebar";
import { ThemeProvider } from "@/components/theme-provider";
import { ThemeToggle } from "@/components/theme-toggle";

// Pages
import HomePage from "@/pages/home";
import ExamOverviewPage from "@/pages/exam-overview";
import RhetoricalDevicesPage from "@/pages/rhetorical-devices-page";
import PracticePromptsPage from "@/pages/practice-prompts-page";
import EssayTemplatesPage from "@/pages/essay-templates-page";
import WritingTipsPage from "@/pages/writing-tips-page";
import SpacecatPage from "@/pages/spacecat-page";
import MCQStrategiesPage from "@/pages/mcq-strategies-page";
import NotFound from "@/pages/not-found";

function Router() {
  return (
    <Switch>
      <Route path="/overview/format" component={ExamOverviewPage} />
      <Route path="/overview/scoring" component={ExamOverviewPage} />
      <Route path="/overview/timeline" component={ExamOverviewPage} />
      
      <Route path="/rhetorical-analysis/overview" component={EssayTemplatesPage} />
      <Route path="/rhetorical-analysis/spacecat" component={SpacecatPage} />
      <Route path="/rhetorical-analysis/examples" component={RhetoricalDevicesPage} />
      <Route path="/rhetorical-analysis/rubric" component={EssayTemplatesPage} />
      
      <Route path="/argument/overview" component={EssayTemplatesPage} />
      <Route path="/argument/thesis" component={WritingTipsPage} />
      <Route path="/argument/evidence" component={WritingTipsPage} />
      <Route path="/argument/rubric" component={EssayTemplatesPage} />
      
      <Route path="/synthesis/overview" component={EssayTemplatesPage} />
      <Route path="/synthesis/sources" component={WritingTipsPage} />
      <Route path="/synthesis/tips" component={WritingTipsPage} />
      <Route path="/synthesis/rubric" component={EssayTemplatesPage} />
      
      <Route path="/mcq/strategies" component={MCQStrategiesPage} />
      <Route path="/mcq/time" component={MCQStrategiesPage} />
      <Route path="/mcq/traps" component={MCQStrategiesPage} />
      
      <Route path="/devices/appeals" component={RhetoricalDevicesPage} />
      <Route path="/devices/syntax" component={RhetoricalDevicesPage} />
      <Route path="/devices/figurative" component={RhetoricalDevicesPage} />
      <Route path="/devices/all" component={RhetoricalDevicesPage} />
      
      <Route path="/tips/sophistication" component={WritingTipsPage} />
      <Route path="/tips/syntax" component={WritingTipsPage} />
      <Route path="/tips/transitions" component={WritingTipsPage} />
      <Route path="/tips/pitfalls" component={WritingTipsPage} />
      <Route path="/tips/all" component={WritingTipsPage} />
      
      <Route path="/templates/all" component={EssayTemplatesPage} />
      
      <Route path="/practice/all" component={PracticePromptsPage} />
      <Route path="/practice/rhetorical-analysis" component={PracticePromptsPage} />
      <Route path="/practice/argument" component={PracticePromptsPage} />
      <Route path="/practice/synthesis" component={PracticePromptsPage} />
      
      <Route path="/study/3-month" component={HomePage} />
      <Route path="/study/2-month" component={HomePage} />
      <Route path="/study/1-month" component={HomePage} />
      
      <Route path="/resources/cheat-sheets" component={WritingTipsPage} />
      <Route path="/resources/tone-words" component={RhetoricalDevicesPage} />
      <Route path="/resources/verbs" component={RhetoricalDevicesPage} />
      
      <Route component={NotFound} />
    </Switch>
  );
}

export default function App() {
  const style = {
    "--sidebar-width": "16rem",
    "--sidebar-width-icon": "3rem",
  };

  return (
    <QueryClientProvider client={queryClient}>
      <ThemeProvider defaultTheme="light">
        <TooltipProvider>
          <div className="min-h-screen bg-background">
            <Switch>
              <Route path="/" component={HomePage} />
              <Route>
                <SidebarProvider style={style as React.CSSProperties}>
                  <div className="flex h-screen w-full">
                    <AppSidebar />
                    <div className="flex flex-col flex-1 overflow-hidden">
                      <header className="flex items-center justify-between p-4 border-b bg-background sticky top-0 z-10">
                        <SidebarTrigger data-testid="button-sidebar-toggle" />
                        <ThemeToggle />
                      </header>
                      <main className="flex-1 overflow-y-auto">
                        <Router />
                      </main>
                    </div>
                  </div>
                </SidebarProvider>
              </Route>
            </Switch>
          </div>
          <Toaster />
        </TooltipProvider>
      </ThemeProvider>
    </QueryClientProvider>
  );
}
