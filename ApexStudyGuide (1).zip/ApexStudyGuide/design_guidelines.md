# AP Language Exam Guide - Design Guidelines

## Design Approach: Educational Documentation System

**Primary Inspiration**: Modern documentation platforms (Stripe Docs, Tailwind Docs) + Educational interfaces (Khan Academy, Notion)

**Core Principle**: Information density with exceptional readability. Create a professional learning environment that makes complex AP Lang concepts accessible and scannable.

## Typography System

**Font Families** (via Google Fonts CDN):
- Headings: Inter (weights: 600, 700, 800)
- Body Text: Inter (weights: 400, 500)
- Code/Examples: JetBrains Mono (weight: 400)

**Type Scale**:
- Hero Headline: text-5xl md:text-6xl lg:text-7xl font-bold
- Section Headers: text-3xl md:text-4xl font-bold
- Subsection Headers: text-2xl md:text-3xl font-semibold
- Card/Component Titles: text-xl font-semibold
- Body Text: text-base leading-relaxed
- Small Text/Captions: text-sm
- Labels/Tags: text-xs font-medium uppercase tracking-wide

## Layout System

**Spacing Primitives**: Tailwind units of 2, 4, 6, 8, 12, 16, 24
- Tight spacing: gap-2, p-2
- Standard spacing: gap-4, p-4, m-4
- Section padding: py-12 md:py-16 lg:py-24
- Component margins: mb-6, mb-8, mb-12

**Container Strategy**:
- Max-width: max-w-7xl for main content areas
- Sidebar navigation: w-64 fixed/sticky
- Content with sidebar: ml-64 max-w-4xl
- Full-width sections: w-full with inner max-w-7xl px-6

**Grid Patterns**:
- Feature cards: grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6
- Two-column layout: grid-cols-1 lg:grid-cols-2 gap-8
- Resource cards: grid-cols-1 md:grid-cols-2 gap-4

## Component Library

### Navigation Structure
**Top Navigation Bar**: Sticky header with logo, main sections (Exam Overview, Essay Types, Strategies, Practice, Resources), search bar, and CTA button
**Sidebar Navigation** (for content pages): Hierarchical menu with expandable sections, active state indicators, smooth scroll anchors

### Hero Section
**Layout**: Full-width hero (min-h-[70vh]) with centered content
**Content**: Bold headline (e.g., "Master the AP Lang Exam"), subheadline explaining comprehensive guide, dual CTAs ("Start Learning" + "Browse Topics")
**Visual**: Abstract educational imagery showing study materials, notebooks, or minimalist representation of writing/analysis (NOT students at desks)

### Content Sections

**Exam Overview Cards**: Large cards with icons (from Heroicons), section names (MCQ, Rhetorical Analysis, Argument, Synthesis), time allocations, scoring weights

**Strategy Guides**: Two-column layout with methodology on left, annotated examples on right. Use bordered containers with subtle shadows (shadow-sm)

**Rhetorical Device Library**: Searchable grid of cards, each containing term, definition, effect, and example. Tags for filtering (Appeals, Syntax, Figurative Language)

**Essay Templates**: Step-by-step accordion sections with expandable outlines, formula boxes with monospace font, timing indicators

**Sample Essays**: Tabbed interface switching between score levels (3, 5, 7, 9), with inline annotations using highlights and margin notes

**Practice Prompts**: Card-based collection with difficulty badges, theme tags, quick actions (View Prompt, See Sample Response)

### Interactive Components

**Prompt Dissection Tool**: Multi-panel interface with original prompt, color-coded breakdown (task verbs highlighted, requirements underlined), checklist sidebar

**Study Schedule Builder**: Timeline visualization with customizable milestones, progress indicators, printable PDF export option

**Quick Reference Cheat Sheets**: Accordion menus or expandable panels with organized lists (rhetorical appeals, tone words, transition phrases), download icons

**Search Functionality**: Prominent search bar with instant results overlay, categorized suggestions (Topics, Devices, Strategies)

### Supporting Elements

**Callout Boxes**: Bordered containers with left accent for tips (💡), warnings (⚠️), pro strategies (⭐), common mistakes (❌)

**Progress Indicators**: Breadcrumb navigation for multi-page content, completion checkmarks for study plan sections

**Table of Contents**: Sticky sidebar on long-form guides with active section highlighting, smooth scroll behavior

**Footer**: Multi-column layout with Quick Links (all main sections), Resources (downloadable PDFs), About (GitHub repository link, contribution guidelines), newsletter signup

## Page Structure

### Homepage
1. Hero section with value proposition
2. Three-column feature grid (Comprehensive Strategies, Real Examples, Practice Prompts)
3. Exam breakdown section with four cards (MCQ + 3 FRQs)
4. Quick start guide with numbered steps
5. Featured resources showcase
6. CTA section with community/GitHub link

### Content Pages
Layout: Sidebar navigation (left) + main content area (right)
- Sticky table of contents in sidebar
- Main content with clear heading hierarchy
- Related topics footer section
- Pagination/Next Topic navigation

## Icons & Assets

**Icons**: Heroicons (via CDN) for UI elements, section headers, navigation
**Custom Needs**: 
- <!-- CUSTOM ICON: Rhetorical triangle diagram -->
- <!-- CUSTOM ICON: Essay structure flowchart -->

## Images

**Hero Section**: Abstract composition featuring open notebook with pen, highlighters, study materials arranged artistically on clean surface - overhead shot with excellent lighting (1920x1080)

**Strategy Section Headers**: Minimalist icons representing each essay type - no photographic images needed for these sections

**Sample Essay Sections**: Clean annotated text screenshots showing highlighting and margin notes - these should be generated as styled HTML, not images

**No student/classroom photography** - keep visual language professional and focused on materials/concepts

## Accessibility & Interactions

- Maintain WCAG AA contrast ratios for all text
- Keyboard navigation for all interactive elements
- Focus states using ring utilities (ring-2 ring-offset-2)
- Smooth scroll behavior for anchor links (scroll-smooth)
- Skip-to-content link for keyboard users
- Minimal animations: subtle hover lifts on cards (hover:shadow-md transition-shadow), smooth accordion expansions

## Content Density Philosophy

Balance information richness with breathing room. Use generous line-height (leading-relaxed) for body text, strategic whitespace between sections, but don't be afraid of substantial content blocks. This is a study guide - students expect depth, not minimalism.