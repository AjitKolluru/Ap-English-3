import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertBookmarkSchema, insertStudyProgressSchema } from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  // Bookmarks routes
  app.get("/api/bookmarks", async (_req, res) => {
    try {
      const bookmarks = await storage.getBookmarks();
      res.json(bookmarks);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.post("/api/bookmarks", async (req, res) => {
    try {
      const validatedData = insertBookmarkSchema.parse(req.body);
      const bookmark = await storage.createBookmark(validatedData);
      res.status(201).json(bookmark);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  app.delete("/api/bookmarks/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const success = await storage.deleteBookmark(id);
      if (success) {
        res.status(204).send();
      } else {
        res.status(404).json({ error: "Bookmark not found" });
      }
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Study Progress routes
  app.get("/api/progress", async (_req, res) => {
    try {
      const progress = await storage.getStudyProgress();
      res.json(progress);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.get("/api/progress/:sectionId", async (req, res) => {
    try {
      const { sectionId } = req.params;
      const progress = await storage.getProgressBySection(sectionId);
      if (progress) {
        res.json(progress);
      } else {
        res.status(404).json({ error: "Progress not found" });
      }
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.post("/api/progress", async (req, res) => {
    try {
      const validatedData = insertStudyProgressSchema.parse(req.body);
      const progress = await storage.updateStudyProgress(validatedData);
      res.json(progress);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
