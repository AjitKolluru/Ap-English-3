import { type InsertBookmark, type Bookmark, type InsertStudyProgress, type StudyProgress } from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  // Bookmarks
  getBookmarks(): Promise<Bookmark[]>;
  createBookmark(bookmark: InsertBookmark): Promise<Bookmark>;
  deleteBookmark(id: string): Promise<boolean>;
  
  // Study Progress
  getStudyProgress(): Promise<StudyProgress[]>;
  updateStudyProgress(progress: InsertStudyProgress): Promise<StudyProgress>;
  getProgressBySection(sectionId: string): Promise<StudyProgress | undefined>;
}

export class MemStorage implements IStorage {
  private bookmarks: Map<string, Bookmark>;
  private studyProgress: Map<string, StudyProgress>;

  constructor() {
    this.bookmarks = new Map();
    this.studyProgress = new Map();
  }

  // Bookmarks
  async getBookmarks(): Promise<Bookmark[]> {
    return Array.from(this.bookmarks.values());
  }

  async createBookmark(insertBookmark: InsertBookmark): Promise<Bookmark> {
    const id = randomUUID();
    const bookmark: Bookmark = {
      ...insertBookmark,
      id,
      createdAt: new Date()
    };
    this.bookmarks.set(id, bookmark);
    return bookmark;
  }

  async deleteBookmark(id: string): Promise<boolean> {
    return this.bookmarks.delete(id);
  }

  // Study Progress
  async getStudyProgress(): Promise<StudyProgress[]> {
    return Array.from(this.studyProgress.values());
  }

  async updateStudyProgress(insertProgress: InsertStudyProgress): Promise<StudyProgress> {
    const existing = Array.from(this.studyProgress.values()).find(
      p => p.sectionId === insertProgress.sectionId
    );

    if (existing) {
      const updated: StudyProgress = {
        ...existing,
        completed: insertProgress.completed,
        lastVisited: new Date()
      };
      this.studyProgress.set(existing.id, updated);
      return updated;
    } else {
      const id = randomUUID();
      const progress: StudyProgress = {
        ...insertProgress,
        id,
        lastVisited: new Date()
      };
      this.studyProgress.set(id, progress);
      return progress;
    }
  }

  async getProgressBySection(sectionId: string): Promise<StudyProgress | undefined> {
    return Array.from(this.studyProgress.values()).find(
      p => p.sectionId === sectionId
    );
  }
}

export const storage = new MemStorage();
