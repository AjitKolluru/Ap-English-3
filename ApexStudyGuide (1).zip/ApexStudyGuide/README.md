# AP Language & Composition Exam Guide

> The most comprehensive, interactive study guide for the AP English Language and Composition exam

## 🎯 Overview

This is a complete, open-source preparation resource for AP Lang students featuring:

- **Comprehensive Exam Coverage**: Detailed breakdowns of all exam sections (MCQ, Rhetorical Analysis, Argument, Synthesis)
- **50+ Rhetorical Devices**: Complete library with definitions, effects, and real AP exam examples
- **20+ Practice Prompts**: Authentic AP-style prompts across all three essay types with sample responses
- **Essay Templates**: Step-by-step structures with timing strategies and formulas
- **SPACECAT Framework**: Systematic approach to rhetorical analysis
- **Writing Tips Database**: Sophistication strategies, syntax variety, transitions, and common pitfalls
- **MCQ Strategies**: Proven techniques for the multiple choice section
- **Interactive Features**: Searchable content, filterable prompts, and organized navigation

## ✨ Features

### For Students

- **Structured Learning Paths**: Follow comprehensive guides from exam overview to advanced strategies
- **Practice Materials**: 20+ real AP-style prompts with difficulty ratings and sample responses
- **Quick Reference**: Searchable rhetorical devices library and downloadable cheat sheets
- **Time Management**: Detailed timing breakdowns for each essay type
- **Dark Mode**: Comfortable studying any time of day

### For Teachers

- **Classroom Ready**: Share the link with students for a complete study resource
- **Open Source**: Contribute additional content, prompts, or improvements
- **No Account Required**: Instant access to all materials

## 🚀 Getting Started

### For Students Using the Guide

1. Visit the deployed site
2. Start with **Exam Overview** to understand the format
3. Learn the **SPACECAT Framework** for rhetorical analysis
4. Study **Rhetorical Devices** (50+ terms with examples)
5. Review **Essay Templates** for all three FRQ types
6. Practice with **20+ Prompts** and compare to sample responses
7. Master **Writing Tips** to increase sophistication
8. Learn **MCQ Strategies** for the multiple choice section

### For Developers

#### Local Development

```bash
# Clone the repository
git clone <your-repo-url>
cd ap-lang-exam-guide

# Install dependencies
npm install

# Start development server
npm run dev

# Open http://localhost:5000
```

#### Deployment to GitHub Pages

1. **Update Package.json** (if needed):
```json
{
  "homepage": "https://yourusername.github.io/ap-lang-exam-guide"
}
```

2. **Build the Project**:
```bash
npm run build
```

3. **Deploy to GitHub Pages**:
- Push your code to GitHub
- Go to repository Settings → Pages
- Set source to "GitHub Actions" or use gh-pages branch
- Your site will be live at `https://yourusername.github.io/ap-lang-exam-guide`

#### Alternative Deployment Options

**Vercel**:
```bash
npm i -g vercel
vercel
```

**Netlify**:
- Drag and drop the `dist` folder to Netlify
- Or connect your GitHub repository

**Replit**:
- This project is already configured for Replit
- Just fork and run!

## 📚 Content Overview

### Exam Sections Covered

- **Multiple Choice** (45% of score): Reading strategies, time management, trap avoidance
- **Rhetorical Analysis** (~18% of score): SPACECAT framework, device identification, analysis techniques
- **Argument Essay** (~18% of score): Thesis formulas, evidence selection, counterarguments
- **Synthesis Essay** (~18% of score): Source integration, citation, synthesis vs. summary

### Key Features

#### Rhetorical Devices Library
- 50+ devices categorized by type
- Searchable and filterable
- Real AP exam examples
- Effect explanations

#### Practice Prompts Collection
- Rhetorical Analysis (6 prompts)
- Argument Essays (7 prompts)
- Synthesis Essays (7 prompts)
- Difficulty ratings: Easy, Medium, Hard
- Sample response openings
- Scoring rubric guidance

#### Essay Templates
- Complete structures for all three FRQ types
- Time allocation for each section
- Paragraph-by-paragraph guides
- Formulas and frameworks
- Essential tips and strategies

#### Writing Tips
- **Sophistication**: Qualifying claims, addressing complexity, making connections
- **Syntax Variety**: Sentence openers, lengths, periodic sentences, parallelism
- **Transitions**: Addition, contrast, cause/effect, exemplification
- **Pitfalls**: Plot summary, vague language, weak verbs, common mistakes

## 🛠️ Tech Stack

- **Frontend**: React, TypeScript, Tailwind CSS
- **UI Components**: shadcn/ui (Radix primitives)
- **Routing**: Wouter
- **State Management**: TanStack Query
- **Build Tool**: Vite
- **Backend**: Express.js (for future features)

## 📖 Usage Guide

### Navigating the Site

1. **Homepage**: Overview of exam format and quick start guide
2. **Sidebar Navigation**: Access all sections organized by topic
3. **Search**: Find rhetorical devices quickly
4. **Filters**: Sort practice prompts by type and difficulty
5. **Dark Mode**: Toggle in header for comfortable reading

### Study Recommendations

**3-Month Plan**:
- Month 1: Exam overview, SPACECAT, rhetorical devices
- Month 2: Essay templates, writing tips, MCQ strategies
- Month 3: Practice prompts, timed writing, review

**1-Month Plan**:
- Week 1: Exam format, SPACECAT, key devices
- Week 2: Essay templates for all three types
- Week 3: Practice prompts, sophistication tips
- Week 4: MCQ strategies, final review, timed practice

## 🤝 Contributing

Contributions are welcome! Here's how you can help:

### Adding Content

- **New Practice Prompts**: Add to `client/src/data/practicePrompts.ts`
- **Rhetorical Devices**: Add to `client/src/data/rhetoricalDevices.ts`
- **Writing Tips**: Add to `client/src/data/writingTips.ts`

### Improving Features

- Better search functionality
- Additional filters and sorting
- PDF export for cheat sheets
- Progress tracking
- Flashcard mode for devices

### Reporting Issues

Found a typo or error? Open an issue on GitHub with:
- Page/section where error occurs
- Description of the issue
- Suggested correction

## 📄 License

MIT License - feel free to use, modify, and distribute

## 🎓 For Educators

This resource is completely free for classroom use. You may:
- Share the link with students
- Use content in lesson plans
- Modify for your curriculum
- Host your own version with custom content

## 🌟 Acknowledgments

- AP® is a trademark registered by the College Board, which is not affiliated with, and does not endorse, this project
- Content compiled from public AP Lang resources, best practices, and teaching experience
- Built with modern web technologies for accessibility and performance

## 📞 Support

- **Issues**: GitHub Issues
- **Questions**: Open a discussion on GitHub
- **Suggestions**: Pull requests welcome!

---

**Good luck on the AP Lang exam!** 🎉

Remember: Success comes from understanding rhetoric, practicing consistently, and developing your analytical voice. This guide provides the tools—you provide the effort!
