# AP Language & Composition Exam Guide

## Project Overview

A comprehensive, interactive study guide for AP English Language and Composition exam preparation. This application provides students with everything they need to excel on the AP Lang exam, including rhetorical analysis frameworks, essay templates, practice prompts, writing tips, and MCQ strategies.

## Recent Changes (November 19, 2025)

### Initial Implementation
- Complete MVP implementation with all core features
- 50+ rhetorical devices with searchable/filterable library
- 20+ practice prompts across all three essay types
- Comprehensive essay templates with timing strategies
- SPACECAT framework for rhetorical analysis
- MCQ strategies and techniques
- Writing tips database (sophistication, syntax, transitions, pitfalls)
- Dark mode support
- Responsive design for all screen sizes

## Architecture

### Frontend (`client/`)
- **Framework**: React 18 with TypeScript
- **Routing**: Wouter for client-side routing
- **Styling**: Tailwind CSS with shadcn/ui components
- **State**: TanStack Query for data fetching
- **Theme**: Custom theme provider with light/dark mode

### Backend (`server/`)
- **Runtime**: Express.js with TypeScript
- **Storage**: In-memory storage (MemStorage) for session data
- **API**: RESTful endpoints for bookmarks and study progress

### Data Models (`shared/schema.ts`)
- Study Progress tracking
- Bookmark management
- Rhetorical Devices (50+ terms)
- Practice Prompts (20+ across all types)
- Essay Templates
- Writing Tips

## Key Features

### Content Library
1. **Exam Overview**: Complete breakdown of exam format, timing, and scoring
2. **Rhetorical Devices**: 50+ devices categorized (Appeals, Syntax, Figurative Language, Diction, Other) with:
   - Definitions
   - Effect explanations
   - Real AP exam examples
   - Search and filter functionality

3. **Practice Prompts**: 20+ authentic AP-style prompts:
   - Rhetorical Analysis (6 prompts)
   - Argument Essays (7 prompts)
   - Synthesis Essays (7 prompts)
   - Difficulty ratings (Easy, Medium, Hard)
   - Sample responses
   - Rubric guidance

4. **Essay Templates**: Step-by-step structures for all three FRQ types:
   - Time allocation breakdowns
   - Paragraph-by-paragraph guides
   - Formulas and frameworks
   - Essential tips

5. **SPACECAT Framework**: Comprehensive rhetorical analysis framework covering:
   - Speaker, Purpose, Audience
   - Context, Exigence, Choices
   - Appeals, Tone

6. **Writing Tips**: Organized by category:
   - Sophistication strategies
   - Syntax variety techniques
   - Transition words and phrases
   - Common pitfalls to avoid

7. **MCQ Strategies**: Multiple choice section guidance:
   - Reading strategies
   - Time management
   - Question types
   - Common traps

### User Features
- **Dark Mode**: Full dark mode support with theme toggle
- **Responsive Design**: Optimized for desktop, tablet, and mobile
- **Sidebar Navigation**: Hierarchical navigation with collapsible sections
- **Search**: Real-time search for rhetorical devices
- **Filters**: Filter prompts by type and difficulty
- **Interactive Dialogs**: View full prompts in modal dialogs

## File Structure

```
client/
├── src/
│   ├── components/
│   │   ├── ui/               # shadcn/ui components
│   │   ├── app-sidebar.tsx   # Main navigation sidebar
│   │   ├── theme-provider.tsx
│   │   └── theme-toggle.tsx
│   ├── data/
│   │   ├── rhetoricalDevices.ts  # 50+ device definitions
│   │   ├── practicePrompts.ts    # 20+ practice prompts
│   │   ├── essayTemplates.ts     # Essay structures
│   │   ├── writingTips.ts        # Writing improvement tips
│   │   └── sections.ts           # Navigation structure
│   ├── pages/
│   │   ├── home.tsx
│   │   ├── exam-overview.tsx
│   │   ├── rhetorical-devices-page.tsx
│   │   ├── practice-prompts-page.tsx
│   │   ├── essay-templates-page.tsx
│   │   ├── writing-tips-page.tsx
│   │   ├── spacecat-page.tsx
│   │   └── mcq-strategies-page.tsx
│   ├── App.tsx               # Main app with routing
│   └── index.css             # Tailwind config and theme
├── index.html
server/
├── storage.ts                # In-memory storage
├── routes.ts                 # API endpoints
└── index.ts                  # Express server
shared/
└── schema.ts                 # TypeScript types and schemas
```

## API Endpoints

### Bookmarks
- `GET /api/bookmarks` - Get all bookmarks
- `POST /api/bookmarks` - Create bookmark
- `DELETE /api/bookmarks/:id` - Delete bookmark

### Study Progress
- `GET /api/progress` - Get all progress
- `GET /api/progress/:sectionId` - Get progress for section
- `POST /api/progress` - Update progress

## Design System

### Typography
- **Headings**: Inter (600, 700, 800)
- **Body**: Inter (400, 500)
- **Code/Examples**: JetBrains Mono (400)

### Color Scheme
- **Primary**: Blue (#3b82f6) - Used for interactive elements
- **Chart Colors**: Green, Purple, Orange for differentiation
- **Background**: White (light) / Dark slate (dark)
- **Muted**: Subtle backgrounds and secondary text

### Components
- All using shadcn/ui for consistency
- Hover elevate effects for interactive elements
- Smooth transitions and animations
- Responsive grid layouts

## Development

### Running Locally
```bash
npm install
npm run dev
# Visit http://localhost:5000
```

### Building for Production
```bash
npm run build
```

## Deployment

### GitHub Pages
1. Build the project: `npm run build`
2. Deploy the `dist` folder to GitHub Pages
3. Configure GitHub Pages in repository settings

### Replit
- Project is already configured for Replit
- Click "Run" to start the development server

## User Preferences
None currently stored (future feature for personalization)

## Content Guidelines

### Adding New Content
- **Rhetorical Devices**: Add to `client/src/data/rhetoricalDevices.ts`
- **Practice Prompts**: Add to `client/src/data/practicePrompts.ts`
- **Writing Tips**: Add to `client/src/data/writingTips.ts`
- **Essay Templates**: Add to `client/src/data/essayTemplates.ts`

### Content Structure
All content is structured as TypeScript data with strong typing for maintainability and consistency.

## Future Enhancements

Potential features for future development:
- User accounts and authentication
- Personal study schedules and timelines
- Progress tracking across sessions
- Flashcard mode for rhetorical devices
- PDF export for cheat sheets
- Timed essay practice mode
- AI-powered essay feedback
- Community features (shared essays, peer review)

## License
MIT License - Open source for educational use
