import { sql } from "drizzle-orm";
import { pgTable, text, varchar, jsonb, timestamp, integer, boolean } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Study Progress Tracking
export const studyProgress = pgTable("study_progress", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  sectionId: text("section_id").notNull(),
  completed: boolean("completed").notNull().default(false),
  lastVisited: timestamp("last_visited").defaultNow(),
});

export const insertStudyProgressSchema = createInsertSchema(studyProgress).omit({
  id: true,
});

export type InsertStudyProgress = z.infer<typeof insertStudyProgressSchema>;
export type StudyProgress = typeof studyProgress.$inferSelect;

// Bookmarks
export const bookmarks = pgTable("bookmarks", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  contentId: text("content_id").notNull(),
  contentType: text("content_type").notNull(), // 'guide', 'device', 'prompt', etc.
  title: text("title").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertBookmarkSchema = createInsertSchema(bookmarks).omit({
  id: true,
  createdAt: true,
});

export type InsertBookmark = z.infer<typeof insertBookmarkSchema>;
export type Bookmark = typeof bookmarks.$inferSelect;

// Rhetorical Device
export interface RhetoricalDevice {
  id: string;
  term: string;
  definition: string;
  effect: string;
  example: string;
  category: 'appeals' | 'syntax' | 'figurative' | 'diction' | 'other';
}

// Practice Prompt
export interface PracticePrompt {
  id: string;
  type: 'rhetorical-analysis' | 'argument' | 'synthesis';
  title: string;
  prompt: string;
  difficulty: 'easy' | 'medium' | 'hard';
  theme: string[];
  sampleResponse?: string;
  rubric?: string;
}

// Essay Template
export interface EssayTemplate {
  id: string;
  type: 'rhetorical-analysis' | 'argument' | 'synthesis';
  title: string;
  timeAllocation: string;
  structure: {
    section: string;
    timeMinutes: number;
    content: string[];
  }[];
  tips: string[];
}

// Study Schedule
export interface StudyScheduleMilestone {
  week: number;
  focus: string;
  tasks: string[];
  completed: boolean;
}

export interface StudySchedule {
  id: string;
  duration: '1-month' | '2-month' | '3-month';
  milestones: StudyScheduleMilestone[];
}

// Writing Tip
export interface WritingTip {
  id: string;
  category: 'sophistication' | 'syntax' | 'transitions' | 'pitfalls';
  title: string;
  description: string;
  examples?: string[];
}

// Sample Essay
export interface SampleEssay {
  id: string;
  promptId: string;
  score: 3 | 5 | 7 | 9;
  essay: string;
  annotations: {
    text: string;
    note: string;
  }[];
  feedback: string;
}

// Section Content for Navigation
export interface Section {
  id: string;
  title: string;
  icon: string;
  subsections?: {
    id: string;
    title: string;
    path: string;
  }[];
}
